-- ============================================
-- CryptoMine Pro - Supabase Database Schema
-- ============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS users (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  telegram_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  username TEXT,
  photo_url TEXT,
  balance DECIMAL(20, 8) DEFAULT 0,
  mining_speed INTEGER DEFAULT 1,
  premium TEXT CHECK (premium IN ('silver', 'gold', 'vip', NULL)),
  premium_expiry TIMESTAMPTZ,
  referral_code TEXT UNIQUE,
  referred_by TEXT,
  boost_expiry TIMESTAMPTZ,
  daily_streak INTEGER DEFAULT 0,
  last_daily_claim TIMESTAMPTZ,
  total_earned DECIMAL(20, 8) DEFAULT 0,
  is_admin BOOLEAN DEFAULT FALSE,
  is_banned BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- MINING SESSIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS mining_sessions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  start_time TIMESTAMPTZ DEFAULT NOW(),
  end_time TIMESTAMPTZ,
  total_earned DECIMAL(20, 8) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- TRANSACTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS transactions (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN (
    'mining', 'daily_reward', 'task', 'referral',
    'ad_reward', 'premium', 'withdrawal', 'bonus', 'spin'
  )),
  amount DECIMAL(20, 8) NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- TASKS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS tasks (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  reward DECIMAL(10, 2) NOT NULL,
  link TEXT,
  type TEXT NOT NULL CHECK (type IN ('telegram', 'ad', 'ad_popup', 'social', 'website', 'referral')),
  icon TEXT DEFAULT '✨',
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- USER TASKS (Completed Tasks)
-- ============================================
CREATE TABLE IF NOT EXISTS user_tasks (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  task_id UUID REFERENCES tasks(id) ON DELETE CASCADE,
  completed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, task_id)
);

-- ============================================
-- WITHDRAWALS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS withdrawals (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  wallet TEXT NOT NULL,
  amount DECIMAL(20, 8) NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'rejected')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================
-- REFERRALS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS referrals (
  id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
  referrer_id UUID REFERENCES users(id) ON DELETE CASCADE,
  referred_id UUID REFERENCES users(id) ON DELETE CASCADE,
  reward DECIMAL(10, 2) DEFAULT 100,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(referred_id)
);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id);
CREATE INDEX IF NOT EXISTS idx_users_referral_code ON users(referral_code);
CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_created_at ON transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_mining_sessions_user_id ON mining_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_tasks_user_id ON user_tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_withdrawals_user_id ON withdrawals(user_id);
CREATE INDEX IF NOT EXISTS idx_withdrawals_status ON withdrawals(status);
CREATE INDEX IF NOT EXISTS idx_referrals_referrer_id ON referrals(referrer_id);

-- ============================================
-- ROW LEVEL SECURITY
-- ============================================

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE mining_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE referrals ENABLE ROW LEVEL SECURITY;

-- Users can read their own data
CREATE POLICY "Users can view own profile" ON users
  FOR SELECT USING (true);

CREATE POLICY "Users can insert own profile" ON users
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Users can update own profile" ON users
  FOR UPDATE USING (true);

-- Mining sessions
CREATE POLICY "Users can manage own sessions" ON mining_sessions
  FOR ALL USING (true);

-- Transactions
CREATE POLICY "Users can view own transactions" ON transactions
  FOR ALL USING (true);

-- Tasks - publicly readable
CREATE POLICY "Tasks are publicly readable" ON tasks
  FOR SELECT USING (is_active = TRUE);

-- User tasks
CREATE POLICY "Users can manage own tasks" ON user_tasks
  FOR ALL USING (true);

-- Withdrawals
CREATE POLICY "Users can manage own withdrawals" ON withdrawals
  FOR ALL USING (true);

-- Referrals
CREATE POLICY "Referrals are readable" ON referrals
  FOR ALL USING (true);

-- ============================================
-- SEED DEFAULT TASKS
-- ============================================
INSERT INTO tasks (title, description, reward, link, type, icon, is_active) VALUES
  ('Join Telegram Channel', 'Join our official Telegram channel for updates', 50, 'https://t.me/cryptominepro', 'telegram', '📢', TRUE),
  ('Watch an Ad', 'Watch a short advertisement to earn coins', 25, NULL, 'ad', '📺', TRUE),
  ('Watch Reward Popup Ad', 'Watch popup ad for instant coin reward', 30, NULL, 'ad_popup', '🎁', TRUE),
  ('Follow on Twitter', 'Follow our Twitter account @CryptoMinePro', 40, 'https://twitter.com/cryptominepro', 'social', '🐦', TRUE),
  ('Visit our Website', 'Visit our main website to learn more', 20, 'https://cryptominepro.com', 'website', '🌐', TRUE),
  ('Invite a Friend', 'Invite a friend using your referral link', 100, NULL, 'referral', '👥', TRUE),
  ('Join Discord Server', 'Join our Discord community', 35, 'https://discord.gg/cryptominepro', 'social', '💬', TRUE),
  ('Subscribe on YouTube', 'Subscribe to our YouTube channel', 45, 'https://youtube.com/cryptominepro', 'social', '▶️', TRUE)
ON CONFLICT DO NOTHING;

-- ============================================
-- FUNCTIONS
-- ============================================

-- Function to get leaderboard
CREATE OR REPLACE FUNCTION get_leaderboard(limit_count INTEGER DEFAULT 50)
RETURNS TABLE(
  name TEXT,
  username TEXT,
  total_earned DECIMAL,
  telegram_id TEXT,
  premium TEXT,
  mining_speed INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT u.name, u.username, u.total_earned, u.telegram_id, u.premium, u.mining_speed
  FROM users u
  WHERE u.is_banned = FALSE
  ORDER BY u.total_earned DESC
  LIMIT limit_count;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- ADMIN USER SETUP
-- Set your Telegram ID here to become admin
-- ============================================
-- UPDATE users SET is_admin = TRUE WHERE telegram_id = 'YOUR_TELEGRAM_ID';
