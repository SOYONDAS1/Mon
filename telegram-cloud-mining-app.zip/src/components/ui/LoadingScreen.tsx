export const LoadingScreen = () => {
  return (
    <div className="fixed inset-0 bg-[#060B14] flex items-center justify-center z-50">
      <div className="text-center">
        {/* Animated mining icon */}
        <div className="relative w-24 h-24 mx-auto mb-6">
          <div className="absolute inset-0 rounded-full border-2 border-cyan-500/30 animate-ping" />
          <div className="absolute inset-2 rounded-full border-2 border-cyan-500/50 animate-ping" style={{ animationDelay: '0.2s' }} />
          <div className="absolute inset-4 rounded-full bg-cyan-500/10 border-2 border-cyan-400 flex items-center justify-center">
            <span className="text-3xl">⛏️</span>
          </div>
        </div>

        {/* Logo */}
        <h1 className="text-2xl font-bold text-white mb-1">
          Crypto<span className="text-cyan-400">Mine</span> Pro
        </h1>
        <p className="text-gray-400 text-sm mb-6">Cloud Mining Platform</p>

        {/* Loading bar */}
        <div className="w-48 h-1.5 bg-gray-800 rounded-full mx-auto overflow-hidden">
          <div className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full animate-[loading_1.5s_ease-in-out_infinite]" />
        </div>
        <p className="text-gray-500 text-xs mt-3">Connecting to network...</p>
      </div>

      <style>{`
        @keyframes loading {
          0% { width: 0%; margin-left: 0; }
          50% { width: 70%; margin-left: 0; }
          100% { width: 0%; margin-left: 100%; }
        }
      `}</style>
    </div>
  );
};
