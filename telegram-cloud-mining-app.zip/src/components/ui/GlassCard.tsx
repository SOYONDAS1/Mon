import { ReactNode } from 'react';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  glow?: 'cyan' | 'purple' | 'gold' | 'green' | 'none';
  onClick?: () => void;
  style?: React.CSSProperties;
}

const glowClasses = {
  cyan: 'shadow-[0_0_20px_rgba(0,212,255,0.15)] border-cyan-500/20',
  purple: 'shadow-[0_0_20px_rgba(168,85,247,0.15)] border-purple-500/20',
  gold: 'shadow-[0_0_20px_rgba(255,215,0,0.15)] border-yellow-500/20',
  green: 'shadow-[0_0_20px_rgba(34,197,94,0.15)] border-green-500/20',
  none: 'border-white/10',
};

export const GlassCard = ({ children, className = '', glow = 'none', onClick, style }: GlassCardProps) => {
  return (
    <div
      onClick={onClick}
      style={style}
      className={`
        bg-white/5 backdrop-blur-md border rounded-2xl
        ${glowClasses[glow]}
        ${onClick ? 'cursor-pointer hover:bg-white/8 active:scale-98 transition-all duration-200' : ''}
        ${className}
      `}
    >
      {children}
    </div>
  );
};
