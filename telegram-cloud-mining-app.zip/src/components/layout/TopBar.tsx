import { useNavigate } from 'react-router-dom';
import { useUser } from '../../contexts/UserContext';
import { useMining } from '../../contexts/MiningContext';

export const TopBar = () => {
  const navigate = useNavigate();
  const { user } = useUser();
  const { isMining } = useMining();

  const formatBalance = (balance: number) => {
    if (balance >= 1000000) return `${(balance / 1000000).toFixed(2)}M`;
    if (balance >= 1000) return `${(balance / 1000).toFixed(2)}K`;
    return balance.toFixed(4);
  };

  return (
    <div className="fixed top-0 left-0 right-0 z-50 bg-[#060B14]/95 backdrop-blur-xl border-b border-white/10">
      <div className="flex items-center justify-between px-4 py-3">
        {/* Logo */}
        <div className="flex items-center gap-2" onClick={() => navigate('/')}>
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-400 to-purple-500 flex items-center justify-center text-sm font-bold">
            ⛏️
          </div>
          <span className="font-bold text-sm">
            Crypto<span className="text-cyan-400">Mine</span>
          </span>
        </div>

        {/* Center - Mining Status */}
        {isMining && (
          <div className="flex items-center gap-1.5 bg-green-500/10 border border-green-500/30 rounded-full px-3 py-1">
            <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            <span className="text-green-400 text-xs font-medium">Mining</span>
          </div>
        )}

        {/* Balance + Profile */}
        <div className="flex items-center gap-3">
          <div className="text-right" onClick={() => navigate('/wallet')}>
            <div className="text-xs text-gray-400">Balance</div>
            <div className="text-sm font-bold text-yellow-400">
              🪙 {formatBalance(user?.balance || 0)}
            </div>
          </div>
          <div
            onClick={() => navigate('/profile')}
            className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center text-sm font-bold cursor-pointer"
          >
            {user?.photo_url ? (
              <img src={user.photo_url} alt="Profile" className="w-full h-full rounded-full object-cover" />
            ) : (
              (user?.name || 'U')[0].toUpperCase()
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
