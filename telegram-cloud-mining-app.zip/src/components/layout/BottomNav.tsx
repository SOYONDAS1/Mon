import { useLocation, useNavigate } from 'react-router-dom';
import { useMining } from '../../contexts/MiningContext';

const navItems = [
  { path: '/', icon: '🏠', label: 'Home' },
  { path: '/mining', icon: '⛏️', label: 'Mine' },
  { path: '/tasks', icon: '✅', label: 'Tasks' },
  { path: '/wallet', icon: '💰', label: 'Wallet' },
  { path: '/profile', icon: '👤', label: 'Profile' },
];

export const BottomNav = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { isMining } = useMining();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      {/* Gradient fade */}
      <div className="h-4 bg-gradient-to-t from-[#060B14] to-transparent pointer-events-none" />
      <div className="bg-[#0a0f1e]/98 backdrop-blur-2xl border-t border-white/10">
        <div className="flex items-center justify-around px-1 py-2 pb-safe">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path ||
              (item.path === '/mining' && location.pathname === '/mining');
            const showMiningDot = item.path === '/mining' && isMining;

            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`flex flex-col items-center gap-0.5 py-1.5 px-4 rounded-2xl transition-all duration-200 relative ${
                  isActive
                    ? 'bg-cyan-500/10'
                    : 'hover:bg-white/5'
                }`}
              >
                {/* Mining indicator dot */}
                {showMiningDot && (
                  <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                )}

                <div
                  className={`text-xl transition-all duration-200 ${isActive ? 'scale-110' : 'scale-100 opacity-60'}`}
                  style={{
                    filter: isActive ? 'drop-shadow(0 0 6px rgba(0,212,255,0.8))' : 'none',
                  }}
                >
                  {item.icon}
                </div>
                <span
                  className={`text-[10px] font-semibold transition-colors ${
                    isActive ? 'text-cyan-400' : 'text-gray-600'
                  }`}
                >
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
