import { useMining } from '../../contexts/MiningContext';

interface MiningOrbProps {
  size?: number;
  onClick?: () => void;
}

export const MiningOrb = ({ size = 160, onClick }: MiningOrbProps) => {
  const { isMining, currentSpeed, miningRate } = useMining();

  const speedColor =
    currentSpeed >= 10 ? '#a855f7' :
    currentSpeed >= 5 ? '#FFD700' :
    currentSpeed >= 3 ? '#C0C0C0' :
    currentSpeed >= 2 ? '#22c55e' : '#00d4ff';

  return (
    <div
      className="relative cursor-pointer select-none"
      style={{ width: size, height: size }}
      onClick={onClick}
    >
      {/* Outer glow rings */}
      {isMining && (
        <>
          <div
            className="absolute inset-0 rounded-full animate-ping"
            style={{
              border: `1px solid ${speedColor}`,
              opacity: 0.2,
              animationDuration: '2s',
            }}
          />
          <div
            className="absolute inset-4 rounded-full animate-ping"
            style={{
              border: `1px solid ${speedColor}`,
              opacity: 0.15,
              animationDuration: '2.5s',
              animationDelay: '0.5s',
            }}
          />
        </>
      )}

      {/* Main orb */}
      <div
        className="absolute inset-0 rounded-full flex items-center justify-center"
        style={{
          background: `radial-gradient(circle at 35% 35%, ${speedColor}30, transparent 60%), 
                       radial-gradient(circle at 65% 65%, #0a0f2060, transparent 60%),
                       linear-gradient(135deg, #0d1a2e, #060B14)`,
          border: `2px solid ${speedColor}50`,
          boxShadow: isMining
            ? `0 0 30px ${speedColor}40, 0 0 60px ${speedColor}20, inset 0 0 30px ${speedColor}10`
            : `0 0 15px rgba(255,255,255,0.05), inset 0 0 15px rgba(0,0,0,0.3)`,
          transition: 'all 0.5s ease',
        }}
      >
        {/* Rotating dashed border */}
        <div
          className="absolute inset-2 rounded-full"
          style={{
            border: `2px dashed ${speedColor}30`,
            animation: isMining ? `spin ${3 / currentSpeed}s linear infinite` : 'none',
          }}
        />

        {/* Inner content */}
        <div className="relative z-10 text-center">
          <div
            className="text-5xl mb-1"
            style={{
              filter: isMining ? `drop-shadow(0 0 12px ${speedColor})` : 'none',
              transition: 'filter 0.5s ease',
            }}
          >
            {isMining ? '⛏️' : '🔌'}
          </div>
          <div
            className="text-xs font-bold"
            style={{ color: speedColor }}
          >
            {isMining ? `${(miningRate * 3600).toFixed(3)}/hr` : 'TAP TO MINE'}
          </div>
        </div>
      </div>
    </div>
  );
};
