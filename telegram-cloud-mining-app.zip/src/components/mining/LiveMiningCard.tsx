import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useMining } from '../../contexts/MiningContext';
import { useUser } from '../../contexts/UserContext';
import { GlassCard } from '../ui/GlassCard';

export const LiveMiningCard = () => {
  const navigate = useNavigate();
  const { isMining, miningRate, sessionEarned, elapsedSeconds, currentSpeed, startMining, stopMining } = useMining();
  const { user } = useUser();
  const [displayBalance, setDisplayBalance] = useState(user?.balance || 0);
  const [tick, setTick] = useState(0);

  // Smoothly animate balance increase
  useEffect(() => {
    if (!isMining) {
      setDisplayBalance(user?.balance || 0);
      return;
    }

    const interval = setInterval(() => {
      setTick(t => t + 1);
      setDisplayBalance(prev => prev + miningRate / 10);
    }, 100);

    return () => clearInterval(interval);
  }, [isMining, miningRate, user?.balance]);

  useEffect(() => {
    if (!isMining) {
      setDisplayBalance(user?.balance || 0);
    }
  }, [user?.balance, isMining]);

  const speedColor =
    currentSpeed >= 10 ? '#a855f7' :
    currentSpeed >= 5 ? '#FFD700' :
    currentSpeed >= 3 ? '#C0C0C0' :
    currentSpeed >= 2 ? '#22c55e' : '#00d4ff';

  const formatBalance = (b: number) => {
    if (b >= 1000000) return `${(b / 1000000).toFixed(6)}M`;
    if (b >= 1000) return `${(b / 1000).toFixed(6)}K`;
    return b.toFixed(6);
  };

  void tick;

  return (
    <GlassCard
      className="p-5"
      glow={isMining ? 'cyan' : 'none'}
      onClick={() => navigate('/mining')}
    >
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="text-gray-400 text-xs mb-1">Live Balance</p>
          <div
            className="text-2xl font-bold transition-all duration-100"
            style={{ color: '#FFD700', fontVariantNumeric: 'tabular-nums' }}
          >
            🪙 {formatBalance(displayBalance)}
          </div>
        </div>
        <div className="text-right">
          <div className="flex items-center gap-1.5 justify-end mb-1">
            <div
              className={`w-2 h-2 rounded-full ${isMining ? 'animate-pulse' : ''}`}
              style={{ background: isMining ? '#22c55e' : '#6b7280' }}
            />
            <span className="text-xs" style={{ color: isMining ? '#22c55e' : '#6b7280' }}>
              {isMining ? 'MINING' : 'IDLE'}
            </span>
          </div>
          <div className="text-sm font-bold" style={{ color: speedColor }}>
            ⚡ {currentSpeed}x Speed
          </div>
        </div>
      </div>

      {/* Progress bar */}
      {isMining && (
        <div className="mb-3">
          <div className="flex justify-between text-xs text-gray-500 mb-1">
            <span>Session: +{sessionEarned.toFixed(6)} 🪙</span>
            <span>{Math.floor(elapsedSeconds / 60)}m {elapsedSeconds % 60}s</span>
          </div>
          <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: `${(elapsedSeconds % 60) / 60 * 100}%`,
                background: `linear-gradient(90deg, #00d4ff, ${speedColor})`,
                boxShadow: `0 0 8px ${speedColor}80`,
              }}
            />
          </div>
        </div>
      )}

      <div className="flex items-center gap-2">
        <button
          onClick={(e) => {
            e.stopPropagation();
            isMining ? stopMining() : startMining();
          }}
          className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all border ${
            isMining
              ? 'bg-red-500/10 border-red-500/40 text-red-400 hover:bg-red-500/20'
              : 'bg-cyan-500/15 border-cyan-500/40 text-cyan-400 hover:bg-cyan-500/25'
          }`}
          style={{
            boxShadow: isMining ? '0 0 15px rgba(239,68,68,0.2)' : '0 0 15px rgba(0,212,255,0.2)',
          }}
        >
          {isMining ? '⏹️ Stop Mining' : '⛏️ Start Mining'}
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); navigate('/mining'); }}
          className="px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-gray-400 text-sm hover:bg-white/10"
        >
          Details →
        </button>
      </div>
    </GlassCard>
  );
};
