export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  photo_url?: string;
  language_code?: string;
}

export interface User {
  id: string;
  telegram_id: string;
  name: string;
  username: string | null;
  photo_url: string | null;
  balance: number;
  mining_speed: number;
  premium: string | null;
  premium_expiry: string | null;
  referral_code: string;
  referred_by: string | null;
  boost_expiry: string | null;
  daily_streak: number;
  last_daily_claim: string | null;
  total_earned: number;
  is_admin: boolean;
  is_banned: boolean;
  created_at: string;
}

export interface MiningSession {
  id: string;
  user_id: string;
  start_time: string;
  end_time: string | null;
  total_earned: number;
  created_at: string;
}

export interface Transaction {
  id: string;
  user_id: string;
  type: string;
  amount: number;
  description: string | null;
  created_at: string;
}

export interface Task {
  id: string;
  title: string;
  description: string | null;
  reward: number;
  link: string | null;
  type: string;
  icon: string | null;
  is_active: boolean;
  created_at: string;
}

export interface UserTask {
  id: string;
  user_id: string;
  task_id: string;
  completed_at: string;
}

export interface Withdrawal {
  id: string;
  user_id: string;
  wallet: string;
  amount: number;
  status: string;
  created_at: string;
}

export interface Referral {
  id: string;
  referrer_id: string;
  referred_id: string;
  reward: number;
  created_at: string;
}

export type PremiumPlan = 'silver' | 'gold' | 'vip';

export interface PremiumPlanInfo {
  id: PremiumPlan;
  name: string;
  speed: number;
  price: number;
  color: string;
  duration: number;
  features: string[];
}

export const PREMIUM_PLANS: PremiumPlanInfo[] = [
  {
    id: 'silver',
    name: 'Silver',
    speed: 3,
    price: 9.99,
    color: '#C0C0C0',
    duration: 30,
    features: ['3x Mining Speed', '30 Days Duration', 'Priority Support', 'Silver Badge'],
  },
  {
    id: 'gold',
    name: 'Gold',
    speed: 5,
    price: 19.99,
    color: '#FFD700',
    duration: 30,
    features: ['5x Mining Speed', '30 Days Duration', 'VIP Support', 'Gold Badge', 'Daily Bonus'],
  },
  {
    id: 'vip',
    name: 'VIP',
    speed: 10,
    price: 49.99,
    color: '#a855f7',
    duration: 30,
    features: ['10x Mining Speed', '30 Days Duration', '24/7 Support', 'VIP Badge', 'x2 Daily Bonus', 'Exclusive Tasks'],
  },
];

export const BASE_MINING_RATE = 0.00001; // coins per second at 1x speed
