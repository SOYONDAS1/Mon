import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { User } from '../types';
import { useTelegram } from './TelegramContext';
import toast from 'react-hot-toast';

interface UserContextType {
  user: User | null;
  loading: boolean;
  refreshUser: () => Promise<void>;
  updateBalance: (amount: number, type: string, description?: string) => Promise<void>;
  isAdmin: boolean;
}

const UserContext = createContext<UserContextType>({
  user: null,
  loading: true,
  refreshUser: async () => {},
  updateBalance: async () => {},
  isAdmin: false,
});

const generateReferralCode = (telegramId: number): string => {
  return `CM${telegramId.toString(36).toUpperCase()}${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
};

export const UserProvider = ({ children }: { children: ReactNode }) => {
  const { user: telegramUser, isReady } = useTelegram();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshUser = useCallback(async () => {
    if (!telegramUser) return;

    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('telegram_id', telegramUser.id.toString())
        .single();

      if (error && error.code === 'PGRST116') {
        // User doesn't exist, create them
        const newUser = {
          telegram_id: telegramUser.id.toString(),
          name: `${telegramUser.first_name}${telegramUser.last_name ? ' ' + telegramUser.last_name : ''}`,
          username: telegramUser.username || null,
          photo_url: telegramUser.photo_url || null,
          balance: 0,
          mining_speed: 1,
          premium: null,
          premium_expiry: null,
          referral_code: generateReferralCode(telegramUser.id),
          referred_by: null,
          boost_expiry: null,
          daily_streak: 0,
          last_daily_claim: null,
          total_earned: 0,
          is_admin: false,
          is_banned: false,
        };

        const { data: created, error: createError } = await supabase
          .from('users')
          .insert([newUser])
          .select()
          .single();

        if (createError) {
          console.error('Error creating user:', createError);
          // Use local fallback
          setUser({ ...newUser, id: 'local', created_at: new Date().toISOString() } as User);
        } else {
          setUser(created);
        }
      } else if (data) {
        setUser(data);
      } else {
        // Fallback local user
        const fallbackUser: User = {
          id: 'local',
          telegram_id: telegramUser.id.toString(),
          name: `${telegramUser.first_name}${telegramUser.last_name ? ' ' + telegramUser.last_name : ''}`,
          username: telegramUser.username || null,
          photo_url: telegramUser.photo_url || null,
          balance: 0,
          mining_speed: 1,
          premium: null,
          premium_expiry: null,
          referral_code: generateReferralCode(telegramUser.id),
          referred_by: null,
          boost_expiry: null,
          daily_streak: 0,
          last_daily_claim: null,
          total_earned: 0,
          is_admin: false,
          is_banned: false,
          created_at: new Date().toISOString(),
        };
        setUser(fallbackUser);
      }
    } catch (err) {
      console.error('Error fetching user:', err);
      if (telegramUser) {
        const fallbackUser: User = {
          id: 'local',
          telegram_id: telegramUser.id.toString(),
          name: telegramUser.first_name,
          username: telegramUser.username || null,
          photo_url: null,
          balance: 0,
          mining_speed: 1,
          premium: null,
          premium_expiry: null,
          referral_code: generateReferralCode(telegramUser.id),
          referred_by: null,
          boost_expiry: null,
          daily_streak: 0,
          last_daily_claim: null,
          total_earned: 0,
          is_admin: false,
          is_banned: false,
          created_at: new Date().toISOString(),
        };
        setUser(fallbackUser);
      }
    } finally {
      setLoading(false);
    }
  }, [telegramUser]);

  const updateBalance = useCallback(async (amount: number, type: string, description?: string) => {
    if (!user) return;

    const newBalance = Math.max(0, user.balance + amount);
    const newTotalEarned = amount > 0 ? user.total_earned + amount : user.total_earned;

    // Optimistic update
    setUser(prev => prev ? { ...prev, balance: newBalance, total_earned: newTotalEarned } : null);

    try {
      if (user.id !== 'local') {
        await supabase
          .from('users')
          .update({ balance: newBalance, total_earned: newTotalEarned })
          .eq('id', user.id);

        await supabase
          .from('transactions')
          .insert([{
            user_id: user.id,
            type,
            amount,
            description: description || null,
          }]);
      }
    } catch (err) {
      console.error('Error updating balance:', err);
      toast.error('Balance sync error');
    }
  }, [user]);

  useEffect(() => {
    if (isReady && telegramUser) {
      refreshUser();
    }
  }, [isReady, telegramUser, refreshUser]);

  return (
    <UserContext.Provider value={{
      user,
      loading,
      refreshUser,
      updateBalance,
      isAdmin: user?.is_admin || false,
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => useContext(UserContext);
