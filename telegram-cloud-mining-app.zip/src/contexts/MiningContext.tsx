import { createContext, useContext, useState, useEffect, useRef, useCallback, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import { useUser } from './UserContext';
import { BASE_MINING_RATE } from '../types';

interface MiningContextType {
  isMining: boolean;
  miningRate: number;
  sessionEarned: number;
  elapsedSeconds: number;
  startMining: () => void;
  stopMining: () => void;
  currentSpeed: number;
  boostActive: boolean;
  boostTimeLeft: number;
}

const MiningContext = createContext<MiningContextType>({
  isMining: false,
  miningRate: 0,
  sessionEarned: 0,
  elapsedSeconds: 0,
  startMining: () => {},
  stopMining: () => {},
  currentSpeed: 1,
  boostActive: false,
  boostTimeLeft: 0,
});

export const MiningProvider = ({ children }: { children: ReactNode }) => {
  const { user, updateBalance } = useUser();
  const [isMining, setIsMining] = useState(false);
  const [sessionEarned, setSessionEarned] = useState(0);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [boostActive, setBoostActive] = useState(false);
  const [boostTimeLeft, setBoostTimeLeft] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const sessionIdRef = useRef<string | null>(null);
  const sessionEarnedRef = useRef(0);
  const balanceSyncRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const currentSpeed = (() => {
    if (!user) return 1;
    let speed = user.mining_speed || 1;

    // Check boost
    if (user.boost_expiry) {
      const boostExpiry = new Date(user.boost_expiry).getTime();
      if (Date.now() < boostExpiry) {
        speed = Math.max(speed, 2);
      }
    }

    // Check premium expiry
    if (user.premium && user.premium_expiry) {
      const premiumExpiry = new Date(user.premium_expiry).getTime();
      if (Date.now() > premiumExpiry) {
        speed = 1;
      }
    }

    return speed;
  })();

  const miningRate = BASE_MINING_RATE * currentSpeed;

  useEffect(() => {
    if (!user?.boost_expiry) {
      setBoostActive(false);
      setBoostTimeLeft(0);
      return;
    }

    const checkBoost = () => {
      const boostExpiry = new Date(user.boost_expiry!).getTime();
      const remaining = Math.max(0, Math.floor((boostExpiry - Date.now()) / 1000));
      setBoostActive(remaining > 0);
      setBoostTimeLeft(remaining);
    };

    checkBoost();
    const boostInterval = setInterval(checkBoost, 1000);
    return () => clearInterval(boostInterval);
  }, [user?.boost_expiry]);

  const startMining = useCallback(async () => {
    if (isMining || !user) return;

    setIsMining(true);
    setSessionEarned(0);
    sessionEarnedRef.current = 0;
    setElapsedSeconds(0);

    // Create mining session
    try {
      if (user.id !== 'local') {
        const { data } = await supabase
          .from('mining_sessions')
          .insert([{
            user_id: user.id,
            start_time: new Date().toISOString(),
            total_earned: 0,
          }])
          .select()
          .single();

        if (data) sessionIdRef.current = data.id;
      }
    } catch {}

    // Mining tick every second
    intervalRef.current = setInterval(() => {
      setElapsedSeconds(prev => prev + 1);
      const earned = miningRate;
      sessionEarnedRef.current += earned;
      setSessionEarned(prev => prev + earned);
    }, 1000);

    // Sync balance every 30 seconds
    balanceSyncRef.current = setInterval(async () => {
      if (sessionEarnedRef.current > 0) {
        await updateBalance(sessionEarnedRef.current, 'mining', 'Mining reward');
        sessionEarnedRef.current = 0;
      }
    }, 30000);

  }, [isMining, user, miningRate, updateBalance]);

  const stopMining = useCallback(async () => {
    if (!isMining) return;

    setIsMining(false);

    if (intervalRef.current) clearInterval(intervalRef.current);
    if (balanceSyncRef.current) clearInterval(balanceSyncRef.current);

    // Final balance sync
    if (sessionEarnedRef.current > 0) {
      await updateBalance(sessionEarnedRef.current, 'mining', 'Mining reward');
    }

    // Update session
    if (sessionIdRef.current && user?.id !== 'local') {
      try {
        await supabase
          .from('mining_sessions')
          .update({
            end_time: new Date().toISOString(),
            total_earned: sessionEarned,
          })
          .eq('id', sessionIdRef.current);
      } catch {}
    }

    setSessionEarned(0);
    sessionEarnedRef.current = 0;
    sessionIdRef.current = null;
  }, [isMining, updateBalance, sessionEarned, user?.id]);

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (balanceSyncRef.current) clearInterval(balanceSyncRef.current);
    };
  }, []);

  return (
    <MiningContext.Provider value={{
      isMining,
      miningRate,
      sessionEarned,
      elapsedSeconds,
      startMining,
      stopMining,
      currentSpeed,
      boostActive,
      boostTimeLeft,
    }}>
      {children}
    </MiningContext.Provider>
  );
};

export const useMining = () => useContext(MiningContext);
