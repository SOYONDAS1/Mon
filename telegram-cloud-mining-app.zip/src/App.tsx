import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { TelegramProvider } from './contexts/TelegramContext';
import { UserProvider } from './contexts/UserContext';
import { MiningProvider } from './contexts/MiningContext';
import { TopBar } from './components/layout/TopBar';
import { BottomNav } from './components/layout/BottomNav';
import { LoadingScreen } from './components/ui/LoadingScreen';
import { HomePage } from './pages/HomePage';
import { MiningPage } from './pages/MiningPage';
import { TasksPage } from './pages/TasksPage';
import { WalletPage } from './pages/WalletPage';
import { ProfilePage } from './pages/ProfilePage';
import { PremiumPage } from './pages/PremiumPage';
import { ReferralPage } from './pages/ReferralPage';
import { SpinPage } from './pages/SpinPage';
import { LeaderboardPage } from './pages/LeaderboardPage';
import { AdminPage } from './pages/AdminPage';
import { useUser } from './contexts/UserContext';
import { AnimatedBackground } from './components/ui/AnimatedBackground';

const AppContent = () => {
  const { loading } = useUser();

  if (loading) return <LoadingScreen />;

  return (
    <div className="min-h-screen bg-[#060B14] text-white relative">
      <AnimatedBackground />
      <TopBar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/mining" element={<MiningPage />} />
        <Route path="/tasks" element={<TasksPage />} />
        <Route path="/wallet" element={<WalletPage />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/premium" element={<PremiumPage />} />
        <Route path="/referral" element={<ReferralPage />} />
        <Route path="/spin" element={<SpinPage />} />
        <Route path="/leaderboard" element={<LeaderboardPage />} />
        <Route path="/admin" element={<AdminPage />} />
      </Routes>
      <BottomNav />
    </div>
  );
};

function App() {
  return (
    <BrowserRouter>
      <TelegramProvider>
        <UserProvider>
          <MiningProvider>
            <AppContent />
            <Toaster
              position="top-center"
              toastOptions={{
                duration: 3000,
                style: {
                  background: '#0f172a',
                  color: '#fff',
                  border: '1px solid rgba(255,255,255,0.1)',
                  borderRadius: '12px',
                  fontSize: '14px',
                },
                success: {
                  iconTheme: { primary: '#22c55e', secondary: '#fff' },
                },
                error: {
                  iconTheme: { primary: '#ef4444', secondary: '#fff' },
                },
              }}
            />
          </MiningProvider>
        </UserProvider>
      </TelegramProvider>
    </BrowserRouter>
  );
}

export default App;
