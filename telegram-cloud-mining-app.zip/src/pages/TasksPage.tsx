import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useUser } from '../contexts/UserContext';
import { Task } from '../types';
import { GlassCard } from '../components/ui/GlassCard';
import { NeonButton } from '../components/ui/NeonButton';
import toast from 'react-hot-toast';

declare const show_11024792: ((type?: string | object) => Promise<void>) | undefined;

const DEFAULT_TASKS: Task[] = [
  { id: '1', title: 'Join Telegram Channel', description: 'Join our official channel for updates', reward: 50, link: 'https://t.me/cryptominepro', type: 'telegram', icon: '📢', is_active: true, created_at: '' },
  { id: '2', title: 'Watch an Ad', description: 'Watch a short advertisement', reward: 25, link: null, type: 'ad', icon: '📺', is_active: true, created_at: '' },
  { id: '3', title: 'Watch Reward Ad', description: 'Watch and get instant coins', reward: 30, link: null, type: 'ad_popup', icon: '🎁', is_active: true, created_at: '' },
  { id: '4', title: 'Follow on Twitter', description: 'Follow our Twitter account', reward: 40, link: 'https://twitter.com/cryptominepro', type: 'social', icon: '🐦', is_active: true, created_at: '' },
  { id: '5', title: 'Visit Website', description: 'Visit our main website', reward: 20, link: 'https://cryptominepro.com', type: 'website', icon: '🌐', is_active: true, created_at: '' },
  { id: '6', title: 'Invite a Friend', description: 'Use your referral link to invite a friend', reward: 100, link: null, type: 'referral', icon: '👥', is_active: true, created_at: '' },
];

const DAILY_REWARDS = [10, 20, 30, 50, 75, 100, 200];

export const TasksPage = () => {
  const { user, updateBalance, refreshUser } = useUser();
  const [tasks, setTasks] = useState<Task[]>(DEFAULT_TASKS);
  const [completedTasks, setCompletedTasks] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);
  const [dailyClaimed, setDailyClaimed] = useState(false);
  const [activeTab, setActiveTab] = useState<'daily' | 'tasks'>('daily');

  useEffect(() => {
    fetchTasks();
    checkDailyClaim();
  }, [user]);

  const fetchTasks = async () => {
    try {
      const { data } = await supabase.from('tasks').select('*').eq('is_active', true);
      if (data && data.length > 0) setTasks(data);

      if (user?.id && user.id !== 'local') {
        const { data: userTasks } = await supabase
          .from('user_tasks')
          .select('task_id')
          .eq('user_id', user.id);
        if (userTasks) {
          setCompletedTasks(new Set(userTasks.map((t: { task_id: string }) => t.task_id)));
        }
      }
    } catch {}
  };

  const checkDailyClaim = () => {
    if (!user?.last_daily_claim) return;
    const lastClaim = new Date(user.last_daily_claim);
    const now = new Date();
    const isSameDay = lastClaim.toDateString() === now.toDateString();
    setDailyClaimed(isSameDay);
  };

  const claimDaily = async () => {
    if (dailyClaimed || !user) return;
    setLoading(true);
    try {
      const streak = (user.daily_streak || 0) + 1;
      const rewardIndex = Math.min(streak - 1, DAILY_REWARDS.length - 1);
      const reward = DAILY_REWARDS[rewardIndex];

      if (user.id !== 'local') {
        await supabase.from('users').update({
          daily_streak: streak,
          last_daily_claim: new Date().toISOString(),
        }).eq('id', user.id);
      }

      await updateBalance(reward, 'daily_reward', `Day ${streak} daily reward`);
      await refreshUser();
      setDailyClaimed(true);
      toast.success(`🎁 Daily reward claimed! +${reward} 🪙 (Day ${streak})`, { duration: 4000 });
    } catch {
      toast.error('Failed to claim reward');
    } finally {
      setLoading(false);
    }
  };

  const completeTask = async (task: Task) => {
    if (completedTasks.has(task.id) || !user) return;
    setLoading(true);

    try {
      if (task.type === 'ad') {
        if (typeof show_11024792 !== 'undefined') {
          await show_11024792();
        } else {
          await new Promise(r => setTimeout(r, 1500));
        }
      } else if (task.type === 'ad_popup') {
        if (typeof show_11024792 !== 'undefined') {
          await (show_11024792 as (type: string) => Promise<void>)('pop');
        } else {
          await new Promise(r => setTimeout(r, 1500));
        }
      } else if (task.link) {
        window.open(task.link, '_blank');
        await new Promise(r => setTimeout(r, 2000));
      }

      if (user.id !== 'local') {
        await supabase.from('user_tasks').insert([{
          user_id: user.id,
          task_id: task.id,
        }]);
      }

      await updateBalance(task.reward, 'task', `Task completed: ${task.title}`);
      setCompletedTasks(prev => new Set([...prev, task.id]));
      toast.success(`✅ Task completed! +${task.reward} 🪙`, { duration: 3000 });
    } catch {
      toast.error('Failed to complete task');
    } finally {
      setLoading(false);
    }
  };

  const streak = user?.daily_streak || 0;
  const nextReward = DAILY_REWARDS[Math.min(streak, DAILY_REWARDS.length - 1)];

  return (
    <div className="min-h-screen bg-[#060B14] pb-24 pt-16">
      <div className="px-4 pt-6">
        {/* Header */}
        <h1 className="text-2xl font-bold text-white mb-1">Tasks & Rewards</h1>
        <p className="text-gray-400 text-sm mb-4">Complete tasks to earn coins</p>

        {/* Tabs */}
        <div className="flex gap-2 mb-4">
          {(['daily', 'tasks'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-all ${
                activeTab === tab
                  ? 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-400'
                  : 'bg-white/5 border border-white/10 text-gray-400'
              }`}
            >
              {tab === 'daily' ? '🗓️ Daily' : '✅ Tasks'}
            </button>
          ))}
        </div>

        {activeTab === 'daily' ? (
          <div className="space-y-4">
            {/* Daily Streak */}
            <GlassCard className="p-4" glow="gold">
              <div className="text-center mb-4">
                <div className="text-4xl mb-2">🔥</div>
                <div className="text-2xl font-bold text-yellow-400">{streak} Day Streak</div>
                <div className="text-gray-400 text-sm">Keep mining daily for bigger rewards!</div>
              </div>

              {/* Streak days */}
              <div className="grid grid-cols-7 gap-1 mb-4">
                {DAILY_REWARDS.map((reward, i) => {
                  const dayNum = i + 1;
                  const isPast = i < streak;
                  const isToday = i === streak && !dailyClaimed;
                  const _isFuture = i > streak || (i === streak && dailyClaimed); void _isFuture;

                  return (
                    <div
                      key={i}
                      className={`rounded-lg p-1 text-center transition-all ${
                        isPast ? 'bg-green-500/20 border border-green-500/40' :
                        isToday ? 'bg-yellow-500/20 border border-yellow-500/50 scale-110' :
                        'bg-white/5 border border-white/10'
                      }`}
                    >
                      <div className="text-xs text-gray-400">D{dayNum}</div>
                      <div className={`text-xs font-bold ${
                        isPast ? 'text-green-400' :
                        isToday ? 'text-yellow-400' : 'text-gray-600'
                      }`}>
                        {isPast ? '✓' : `+${reward}`}
                      </div>
                    </div>
                  );
                })}
              </div>

              <NeonButton
                variant="gold"
                size="lg"
                fullWidth
                onClick={claimDaily}
                disabled={dailyClaimed}
                loading={loading}
              >
                {dailyClaimed
                  ? '✅ Claimed Today'
                  : `🎁 Claim +${nextReward} Coins`}
              </NeonButton>

              {dailyClaimed && (
                <p className="text-center text-gray-500 text-xs mt-2">Come back tomorrow for +{DAILY_REWARDS[Math.min(streak, DAILY_REWARDS.length - 1)]} coins!</p>
              )}
            </GlassCard>

            {/* Bonus Chest */}
            <GlassCard className="p-4" glow="purple">
              <div className="flex items-center gap-3">
                <div className="text-4xl">🎰</div>
                <div className="flex-1">
                  <h3 className="font-semibold text-white">Bonus Chest</h3>
                  <p className="text-gray-400 text-xs">Open after 7-day streak</p>
                </div>
                <NeonButton
                  variant="purple"
                  size="sm"
                  disabled={streak < 7}
                >
                  {streak >= 7 ? '🎁 Open!' : `${7 - streak} days`}
                </NeonButton>
              </div>
            </GlassCard>
          </div>
        ) : (
          <div className="space-y-3">
            {tasks.map(task => {
              const isDone = completedTasks.has(task.id);
              return (
                <GlassCard key={task.id} className="p-4" glow={isDone ? 'none' : 'cyan'}>
                  <div className="flex items-center gap-3">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl ${
                      isDone ? 'bg-green-500/20 border border-green-500/30' : 'bg-cyan-500/20 border border-cyan-500/30'
                    }`}>
                      {isDone ? '✅' : task.icon || '✨'}
                    </div>
                    <div className="flex-1">
                      <h3 className={`font-semibold text-sm ${isDone ? 'text-gray-400' : 'text-white'}`}>
                        {task.title}
                      </h3>
                      <p className="text-gray-500 text-xs">{task.description}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-yellow-400 font-bold text-sm">+{task.reward} 🪙</div>
                      {!isDone && (
                        <NeonButton
                          variant="cyan"
                          size="sm"
                          onClick={() => completeTask(task)}
                          loading={loading}
                          className="mt-1"
                        >
                          Do it
                        </NeonButton>
                      )}
                    </div>
                  </div>
                </GlassCard>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
