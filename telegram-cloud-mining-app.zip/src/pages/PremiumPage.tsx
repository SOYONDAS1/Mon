import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { useUser } from '../contexts/UserContext';
import { PREMIUM_PLANS, PremiumPlan } from '../types';
import { GlassCard } from '../components/ui/GlassCard';
import { NeonButton } from '../components/ui/NeonButton';
import toast from 'react-hot-toast';

const CRYPTO_ADDRESSES: Record<string, string> = {
  BTC: '1A1zP1eP5QGefi2DMPTfTL5SLmv7Divfna',
  ETH: '0x742d35Cc6634C0532925a3b844Bc9e57Ef6DeFa',
  USDT: 'TN3W4H6rK2ce4vX9YnFQHwKx8Sn6cRpPnk',
  TON: 'EQD4FPq-PRDieyQKkizFTRtSDyucUIqrj0v_zXJmqaDp6566',
};

export const PremiumPage = () => {
  const { user, refreshUser } = useUser();
  const [selectedPlan, setSelectedPlan] = useState<PremiumPlan | null>(null);
  const [selectedCrypto, setSelectedCrypto] = useState('TON');
  const [paymentStep, setPaymentStep] = useState<'select' | 'payment' | 'confirm'>('select');
  const [txHash, setTxHash] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const currentPlan = PREMIUM_PLANS.find(p => p.id === user?.premium);
  const premiumExpiry = user?.premium_expiry ? new Date(user.premium_expiry) : null;
  const isPremiumActive = premiumExpiry && premiumExpiry > new Date();

  const handleSelectPlan = (planId: PremiumPlan) => {
    setSelectedPlan(planId);
    setPaymentStep('payment');
  };

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(CRYPTO_ADDRESSES[selectedCrypto]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success('Address copied!');
  };

  const handleSubmitPayment = async () => {
    if (!txHash.trim() || !selectedPlan || !user) {
      toast.error('Please enter transaction hash');
      return;
    }

    setLoading(true);
    try {
      const plan = PREMIUM_PLANS.find(p => p.id === selectedPlan)!;
      const expiryDate = new Date(Date.now() + plan.duration * 24 * 60 * 60 * 1000).toISOString();

      if (user.id !== 'local') {
        await supabase.from('users').update({
          premium: selectedPlan,
          premium_expiry: expiryDate,
          mining_speed: plan.speed,
        }).eq('id', user.id);

        await supabase.from('transactions').insert([{
          user_id: user.id,
          type: 'premium',
          amount: -plan.price,
          description: `Upgraded to ${plan.name} plan`,
        }]);
      }

      await refreshUser();
      setPaymentStep('confirm');
      toast.success(`🎉 Welcome to ${plan.name}! ${plan.speed}x speed activated!`, { duration: 5000 });
    } catch {
      toast.error('Payment verification failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#060B14] pb-24 pt-16">
      <div className="px-4 pt-6">
        <h1 className="text-2xl font-bold text-white mb-1">⚡ Premium Plans</h1>
        <p className="text-gray-400 text-sm mb-6">Boost your mining speed with premium</p>

        {/* Current Plan */}
        {isPremiumActive && currentPlan && (
          <GlassCard className="p-4 mb-6" glow="gold">
            <div className="flex items-center gap-3">
              <div className="text-3xl">
                {currentPlan.id === 'silver' ? '🥈' : currentPlan.id === 'gold' ? '🥇' : '💎'}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">{currentPlan.name} Plan Active</span>
                  <span
                    className="text-xs px-2 py-0.5 rounded-full border font-bold"
                    style={{ color: currentPlan.color, borderColor: currentPlan.color + '60', background: currentPlan.color + '20' }}
                  >
                    {currentPlan.speed}x
                  </span>
                </div>
                <p className="text-gray-400 text-xs">Expires: {premiumExpiry?.toLocaleDateString()}</p>
              </div>
            </div>
          </GlassCard>
        )}

        {paymentStep === 'select' && (
          <div className="space-y-4">
            {PREMIUM_PLANS.map(plan => (
              <GlassCard
                key={plan.id}
                className={`p-5 cursor-pointer transition-all ${
                  user?.premium === plan.id ? 'border-2' : ''
                }`}
                style={{
                  borderColor: user?.premium === plan.id ? plan.color + '80' : undefined,
                  boxShadow: user?.premium === plan.id ? `0 0 20px ${plan.color}25` : undefined,
                }}
                onClick={() => handleSelectPlan(plan.id)}
              >
                {/* Plan Header */}
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl"
                    style={{ background: plan.color + '20', border: `1px solid ${plan.color}40` }}
                  >
                    {plan.id === 'silver' ? '🥈' : plan.id === 'gold' ? '🥇' : '💎'}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-xl text-white">{plan.name}</h3>
                      {plan.id === 'gold' && (
                        <span className="text-xs bg-yellow-500/20 border border-yellow-500/40 text-yellow-400 px-2 py-0.5 rounded-full">
                          Popular
                        </span>
                      )}
                      {plan.id === 'vip' && (
                        <span className="text-xs bg-purple-500/20 border border-purple-500/40 text-purple-400 px-2 py-0.5 rounded-full">
                          Best Value
                        </span>
                      )}
                    </div>
                    <div className="text-2xl font-bold" style={{ color: plan.color }}>
                      ${plan.price}/mo
                    </div>
                  </div>
                  <div
                    className="text-2xl font-bold px-3 py-2 rounded-xl"
                    style={{ color: plan.color, background: plan.color + '20' }}
                  >
                    {plan.speed}x
                  </div>
                </div>

                {/* Features */}
                <div className="space-y-2">
                  {plan.features.map((feature, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded-full flex items-center justify-center text-xs" style={{ background: plan.color + '30', color: plan.color }}>
                        ✓
                      </div>
                      <span className="text-gray-300 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                <div
                  className="mt-4 py-2.5 rounded-xl text-center font-semibold text-sm transition-all"
                  style={{
                    background: plan.color + '25',
                    border: `1px solid ${plan.color}50`,
                    color: plan.color,
                  }}
                >
                  {user?.premium === plan.id ? '✅ Current Plan' : `Upgrade to ${plan.name}`}
                </div>
              </GlassCard>
            ))}
          </div>
        )}

        {paymentStep === 'payment' && selectedPlan && (
          <div className="space-y-4">
            <NeonButton variant="ghost" onClick={() => setPaymentStep('select')}>
              ← Back to Plans
            </NeonButton>

            <GlassCard className="p-4" glow="cyan">
              <h2 className="text-white font-bold text-lg mb-1">
                💳 Payment - {PREMIUM_PLANS.find(p => p.id === selectedPlan)?.name}
              </h2>
              <p className="text-gray-400 text-sm mb-4">
                Amount: ${PREMIUM_PLANS.find(p => p.id === selectedPlan)?.price}
              </p>

              {/* Crypto selector */}
              <div className="grid grid-cols-4 gap-2 mb-4">
                {Object.keys(CRYPTO_ADDRESSES).map(crypto => (
                  <button
                    key={crypto}
                    onClick={() => setSelectedCrypto(crypto)}
                    className={`py-2 rounded-xl text-xs font-semibold transition-all border ${
                      selectedCrypto === crypto
                        ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-400'
                        : 'bg-white/5 border-white/10 text-gray-400'
                    }`}
                  >
                    {crypto}
                  </button>
                ))}
              </div>

              {/* Wallet Address */}
              <div className="bg-white/5 border border-white/20 rounded-xl p-3 mb-4">
                <div className="text-gray-400 text-xs mb-1">Send {selectedCrypto} to:</div>
                <div className="text-white text-xs font-mono break-all">{CRYPTO_ADDRESSES[selectedCrypto]}</div>
              </div>

              <NeonButton variant="cyan" size="md" fullWidth onClick={handleCopyAddress}>
                {copied ? '✅ Copied!' : '📋 Copy Address'}
              </NeonButton>
            </GlassCard>

            <GlassCard className="p-4">
              <h3 className="text-white font-semibold mb-2">✅ Confirm Payment</h3>
              <p className="text-gray-400 text-xs mb-3">After sending payment, enter your transaction hash below:</p>
              <input
                type="text"
                value={txHash}
                onChange={e => setTxHash(e.target.value)}
                placeholder="Transaction Hash / TxID"
                className="w-full bg-white/5 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:border-cyan-500/50 focus:outline-none text-sm mb-3"
              />
              <NeonButton
                variant="green"
                size="lg"
                fullWidth
                onClick={handleSubmitPayment}
                loading={loading}
              >
                ✅ Verify & Activate
              </NeonButton>
              <p className="text-gray-600 text-xs text-center mt-2">
                * Plan activates after verification (usually instant)
              </p>
            </GlassCard>
          </div>
        )}

        {paymentStep === 'confirm' && (
          <GlassCard className="p-6 text-center" glow="gold">
            <div className="text-6xl mb-4">🎉</div>
            <h2 className="text-white font-bold text-xl mb-2">Premium Activated!</h2>
            <p className="text-gray-400 mb-4">Your plan is now active. Enjoy faster mining!</p>
            <NeonButton variant="gold" size="lg" fullWidth onClick={() => setPaymentStep('select')}>
              🚀 Start Mining Faster
            </NeonButton>
          </GlassCard>
        )}
      </div>
    </div>
  );
};
