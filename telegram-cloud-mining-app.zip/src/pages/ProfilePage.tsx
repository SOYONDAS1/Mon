import { useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { useMining } from '../contexts/MiningContext';
import { GlassCard } from '../components/ui/GlassCard';
import { NeonButton } from '../components/ui/NeonButton';
import { PREMIUM_PLANS } from '../types';

export const ProfilePage = () => {
  const navigate = useNavigate();
  const { user } = useUser();
  const { currentSpeed } = useMining();

  const plan = PREMIUM_PLANS.find(p => p.id === user?.premium);
  const isPremiumActive = user?.premium_expiry && new Date(user.premium_expiry) > new Date();
  const daysLeft = user?.premium_expiry
    ? Math.max(0, Math.ceil((new Date(user.premium_expiry).getTime() - Date.now()) / 86400000))
    : 0;

  const stats = [
    { label: 'Balance', value: `${(user?.balance || 0).toFixed(4)} 🪙`, icon: '💰' },
    { label: 'Total Earned', value: `${(user?.total_earned || 0).toFixed(4)} 🪙`, icon: '📈' },
    { label: 'Mining Speed', value: `${currentSpeed}x`, icon: '⚡' },
    { label: 'Daily Streak', value: `${user?.daily_streak || 0} days`, icon: '🔥' },
  ];

  const menuItems = [
    { icon: '⛏️', label: 'Mining', path: '/mining', color: 'cyan' },
    { icon: '👑', label: 'Premium Plans', path: '/premium', color: 'gold' },
    { icon: '👥', label: 'Referrals', path: '/referral', color: 'purple' },
    { icon: '💰', label: 'Wallet', path: '/wallet', color: 'green' },
    { icon: '✅', label: 'Tasks', path: '/tasks', color: 'cyan' },
    { icon: '🎡', label: 'Lucky Spin', path: '/spin', color: 'gold' },
    { icon: '🏆', label: 'Leaderboard', path: '/leaderboard', color: 'purple' },
  ];

  if (user?.is_admin) {
    menuItems.push({ icon: '🛡️', label: 'Admin Panel', path: '/admin', color: 'red' });
  }

  return (
    <div className="min-h-screen bg-[#060B14] pb-24 pt-16">
      <div className="px-4 pt-6">
        {/* Profile Header */}
        <GlassCard className="p-5 mb-4" glow="cyan">
          <div className="flex items-center gap-4">
            {/* Avatar */}
            <div className="relative">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-cyan-400 to-purple-500 flex items-center justify-center text-3xl font-bold">
                {user?.photo_url ? (
                  <img src={user.photo_url} alt="" className="w-full h-full rounded-full object-cover" />
                ) : (
                  (user?.name || 'U')[0].toUpperCase()
                )}
              </div>
              {isPremiumActive && plan && (
                <div
                  className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center text-xs border-2 border-[#060B14]"
                  style={{ background: plan.color }}
                >
                  {plan.id === 'silver' ? '🥈' : plan.id === 'gold' ? '🥇' : '💎'}
                </div>
              )}
            </div>

            {/* Info */}
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-bold text-xl text-white">{user?.name}</h2>
                {isPremiumActive && plan && (
                  <span
                    className="text-xs px-2 py-0.5 rounded-full border font-bold"
                    style={{ color: plan.color, borderColor: plan.color + '60', background: plan.color + '15' }}
                  >
                    {plan.name.toUpperCase()}
                  </span>
                )}
                {user?.is_admin && (
                  <span className="text-xs px-2 py-0.5 rounded-full border border-red-500/40 bg-red-500/10 text-red-400 font-bold">
                    ADMIN
                  </span>
                )}
              </div>
              <p className="text-gray-400 text-sm">@{user?.username || 'user'}</p>
              <p className="text-gray-600 text-xs mt-1">ID: {user?.telegram_id}</p>
              {isPremiumActive && (
                <p className="text-xs mt-1" style={{ color: plan?.color }}>
                  Premium expires in {daysLeft} days
                </p>
              )}
            </div>
          </div>
        </GlassCard>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          {stats.map((stat, i) => (
            <GlassCard key={i} className="p-3">
              <div className="text-xl mb-1">{stat.icon}</div>
              <div className="text-white font-bold text-sm">{stat.value}</div>
              <div className="text-gray-500 text-xs">{stat.label}</div>
            </GlassCard>
          ))}
        </div>

        {/* Referral Code */}
        <GlassCard className="p-4 mb-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-400 text-xs">Your Referral Code</p>
              <p className="text-cyan-400 font-mono font-bold text-lg">{user?.referral_code}</p>
            </div>
            <NeonButton variant="cyan" size="sm" onClick={() => navigate('/referral')}>
              Share
            </NeonButton>
          </div>
        </GlassCard>

        {/* Premium CTA */}
        {!isPremiumActive && (
          <GlassCard className="p-4 mb-4" glow="gold">
            <div className="flex items-center gap-3">
              <div className="text-3xl">👑</div>
              <div className="flex-1">
                <h3 className="font-semibold text-white">Upgrade to Premium</h3>
                <p className="text-gray-400 text-xs">Get up to 10x mining speed</p>
              </div>
              <NeonButton variant="gold" size="sm" onClick={() => navigate('/premium')}>
                Upgrade
              </NeonButton>
            </div>
          </GlassCard>
        )}

        {/* Menu Items */}
        <div className="space-y-2">
          {menuItems.map((item) => (
            <GlassCard
              key={item.path}
              className="p-4"
              onClick={() => navigate(item.path)}
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl ${
                  item.color === 'cyan' ? 'bg-cyan-500/20' :
                  item.color === 'gold' ? 'bg-yellow-500/20' :
                  item.color === 'purple' ? 'bg-purple-500/20' :
                  item.color === 'green' ? 'bg-green-500/20' : 'bg-red-500/20'
                }`}>
                  {item.icon}
                </div>
                <span className="text-white font-medium">{item.label}</span>
                <span className="ml-auto text-gray-400">›</span>
              </div>
            </GlassCard>
          ))}
        </div>

        {/* App Info */}
        <div className="text-center mt-6 pb-4">
          <p className="text-gray-600 text-xs">CryptoMine Pro v1.0.0</p>
          <p className="text-gray-700 text-xs">Simulation platform • Not real mining</p>
        </div>
      </div>
    </div>
  );
};
