import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useUser } from '../contexts/UserContext';
import { Transaction, Withdrawal } from '../types';
import { GlassCard } from '../components/ui/GlassCard';
import { NeonButton } from '../components/ui/NeonButton';
import toast from 'react-hot-toast';

const formatDate = (date: string) => {
  return new Date(date).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });
};

const typeIcons: Record<string, string> = {
  mining: '⛏️',
  daily_reward: '🎁',
  task: '✅',
  referral: '👥',
  ad_reward: '📺',
  premium: '👑',
  withdrawal: '💸',
  bonus: '🎰',
};

export const WalletPage = () => {
  const { user, updateBalance } = useUser();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [activeTab, setActiveTab] = useState<'balance' | 'history' | 'withdraw'>('balance');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawWallet, setWithdrawWallet] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user?.id && user.id !== 'local') {
      fetchHistory();
    }
  }, [user]);

  const fetchHistory = async () => {
    if (!user?.id || user.id === 'local') return;
    try {
      const { data: txs } = await supabase
        .from('transactions')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      const { data: wds } = await supabase
        .from('withdrawals')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (txs) setTransactions(txs);
      if (wds) setWithdrawals(wds);
    } catch {}
  };

  const handleWithdraw = async () => {
    if (!user || !withdrawAmount || !withdrawWallet) {
      toast.error('Please fill all fields');
      return;
    }

    const amount = parseFloat(withdrawAmount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Invalid amount');
      return;
    }
    if (amount > (user.balance || 0)) {
      toast.error('Insufficient balance');
      return;
    }
    if (amount < 100) {
      toast.error('Minimum withdrawal is 100 coins');
      return;
    }

    setLoading(true);
    try {
      if (user.id !== 'local') {
        await supabase.from('withdrawals').insert([{
          user_id: user.id,
          wallet: withdrawWallet,
          amount,
          status: 'pending',
        }]);
      }

      await updateBalance(-amount, 'withdrawal', `Withdrawal to ${withdrawWallet.slice(0, 10)}...`);
      toast.success('✅ Withdrawal request submitted! Processing in 24-48 hours.', { duration: 5000 });
      setWithdrawAmount('');
      setWithdrawWallet('');
      fetchHistory();
    } catch {
      toast.error('Failed to submit withdrawal');
    } finally {
      setLoading(false);
    }
  };

  const balance = user?.balance || 0;

  return (
    <div className="min-h-screen bg-[#060B14] pb-24 pt-16">
      <div className="px-4 pt-6">
        {/* Balance Card */}
        <GlassCard className="p-6 mb-4 text-center" glow="gold">
          <div className="text-5xl mb-2">💰</div>
          <div className="text-4xl font-bold text-yellow-400 mb-1">
            {balance.toFixed(4)}
          </div>
          <div className="text-gray-400 text-sm mb-4">🪙 Total Balance</div>

          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white/5 rounded-xl p-3">
              <div className="text-cyan-400 font-bold text-sm">{(user?.total_earned || 0).toFixed(2)}</div>
              <div className="text-gray-500 text-xs">Total Earned</div>
            </div>
            <div className="bg-white/5 rounded-xl p-3">
              <div className="text-purple-400 font-bold text-sm">{transactions.length}</div>
              <div className="text-gray-500 text-xs">Transactions</div>
            </div>
            <div className="bg-white/5 rounded-xl p-3">
              <div className="text-green-400 font-bold text-sm">{withdrawals.length}</div>
              <div className="text-gray-500 text-xs">Withdrawals</div>
            </div>
          </div>
        </GlassCard>

        {/* Tabs */}
        <div className="flex gap-2 mb-4">
          {(['balance', 'history', 'withdraw'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === tab
                  ? 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-400'
                  : 'bg-white/5 border border-white/10 text-gray-400'
              }`}
            >
              {tab === 'balance' ? '📊 Stats' : tab === 'history' ? '📋 History' : '💸 Withdraw'}
            </button>
          ))}
        </div>

        {activeTab === 'balance' && (
          <div className="space-y-3">
            {/* Crypto Assets */}
            <GlassCard className="p-4">
              <h3 className="text-white font-semibold mb-3">💎 Your Assets</h3>
              {[
                { name: 'CryptoMine Coin', symbol: 'CMC', amount: balance, icon: '🪙', color: '#FFD700' },
                { name: 'Mining Power', symbol: 'MHP', amount: (user?.mining_speed || 1) * 100, icon: '⚡', color: '#00d4ff' },
              ].map((asset, i) => (
                <div key={i} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-xl">
                      {asset.icon}
                    </div>
                    <div>
                      <div className="text-white font-medium text-sm">{asset.name}</div>
                      <div className="text-gray-500 text-xs">{asset.symbol}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold" style={{ color: asset.color }}>{asset.amount.toFixed(4)}</div>
                  </div>
                </div>
              ))}
            </GlassCard>

            {/* Mining earnings breakdown */}
            <GlassCard className="p-4">
              <h3 className="text-white font-semibold mb-3">📊 Earnings Breakdown</h3>
              {[
                { type: 'Mining', icon: '⛏️', color: '#00d4ff' },
                { type: 'Daily Rewards', icon: '🎁', color: '#22c55e' },
                { type: 'Tasks', icon: '✅', color: '#a855f7' },
                { type: 'Referrals', icon: '👥', color: '#FFD700' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between py-2">
                  <div className="flex items-center gap-2">
                    <span>{item.icon}</span>
                    <span className="text-gray-400 text-sm">{item.type}</span>
                  </div>
                  <span className="text-sm font-medium" style={{ color: item.color }}>
                    {transactions
                      .filter(t => t.type.includes(item.type.toLowerCase().replace(' ', '_')))
                      .reduce((sum, t) => sum + t.amount, 0)
                      .toFixed(4)} 🪙
                  </span>
                </div>
              ))}
            </GlassCard>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="space-y-2">
            {transactions.length === 0 ? (
              <GlassCard className="p-8 text-center">
                <div className="text-4xl mb-2">📋</div>
                <p className="text-gray-400">No transactions yet</p>
                <p className="text-gray-600 text-xs mt-1">Start mining to see your history</p>
              </GlassCard>
            ) : (
              transactions.map(tx => (
                <GlassCard key={tx.id} className="p-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-xl">
                      {typeIcons[tx.type] || '💰'}
                    </div>
                    <div className="flex-1">
                      <div className="text-white text-sm font-medium capitalize">
                        {tx.type.replace(/_/g, ' ')}
                      </div>
                      <div className="text-gray-500 text-xs">{formatDate(tx.created_at)}</div>
                    </div>
                    <div className={`font-bold text-sm ${tx.amount >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {tx.amount >= 0 ? '+' : ''}{tx.amount.toFixed(4)} 🪙
                    </div>
                  </div>
                </GlassCard>
              ))
            )}
          </div>
        )}

        {activeTab === 'withdraw' && (
          <div className="space-y-4">
            {/* Withdrawal Info */}
            <GlassCard className="p-4" glow="cyan">
              <h3 className="text-white font-semibold mb-2">💸 Withdraw Coins</h3>
              <div className="space-y-1 text-xs text-gray-400">
                <p>• Minimum withdrawal: 100 🪙</p>
                <p>• Processing time: 24-48 hours</p>
                <p>• Supported: BTC, ETH, USDT</p>
              </div>
            </GlassCard>

            <GlassCard className="p-4">
              <div className="space-y-3">
                <div>
                  <label className="text-gray-400 text-xs mb-1 block">Amount (min: 100)</label>
                  <input
                    type="number"
                    value={withdrawAmount}
                    onChange={e => setWithdrawAmount(e.target.value)}
                    placeholder="Enter amount"
                    className="w-full bg-white/5 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:border-cyan-500/50 focus:outline-none text-sm"
                  />
                  <button
                    className="text-cyan-400 text-xs mt-1"
                    onClick={() => setWithdrawAmount((user?.balance || 0).toString())}
                  >
                    Max: {(user?.balance || 0).toFixed(4)}
                  </button>
                </div>

                <div>
                  <label className="text-gray-400 text-xs mb-1 block">Wallet Address</label>
                  <input
                    type="text"
                    value={withdrawWallet}
                    onChange={e => setWithdrawWallet(e.target.value)}
                    placeholder="Enter crypto wallet address"
                    className="w-full bg-white/5 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:border-cyan-500/50 focus:outline-none text-sm"
                  />
                </div>

                <NeonButton
                  variant="cyan"
                  size="lg"
                  fullWidth
                  onClick={handleWithdraw}
                  loading={loading}
                >
                  💸 Submit Withdrawal
                </NeonButton>
              </div>
            </GlassCard>

            {/* Previous withdrawals */}
            {withdrawals.length > 0 && (
              <div>
                <h3 className="text-white font-semibold mb-2">Previous Withdrawals</h3>
                {withdrawals.map(wd => (
                  <GlassCard key={wd.id} className="p-3 mb-2">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-white text-sm">{wd.wallet.slice(0, 12)}...</div>
                        <div className="text-gray-500 text-xs">{formatDate(wd.created_at)}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-yellow-400 font-bold">{wd.amount.toFixed(2)} 🪙</div>
                        <div className={`text-xs px-2 py-0.5 rounded-full ${
                          wd.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                          wd.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                          'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {wd.status}
                        </div>
                      </div>
                    </div>
                  </GlassCard>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
