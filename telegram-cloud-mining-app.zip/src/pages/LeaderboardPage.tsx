import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useUser } from '../contexts/UserContext';
import { GlassCard } from '../components/ui/GlassCard';

interface LeaderEntry {
  name: string;
  username: string;
  total_earned: number;
  telegram_id: string;
  premium: string | null;
  mining_speed: number;
}

export const LeaderboardPage = () => {
  const { user } = useUser();
  const [leaders, setLeaders] = useState<LeaderEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'earnings' | 'speed'>('earnings');

  useEffect(() => {
    fetchLeaderboard();
  }, [activeTab]);

  const fetchLeaderboard = async () => {
    setLoading(true);
    try {
      const orderField = activeTab === 'earnings' ? 'total_earned' : 'mining_speed';
      const { data } = await supabase
        .from('users')
        .select('name, username, total_earned, telegram_id, premium, mining_speed')
        .order(orderField, { ascending: false })
        .limit(50);

      if (data) setLeaders(data);
    } catch {}
    setLoading(false);
  };

  const getPremiumBadge = (premium: string | null) => {
    if (!premium) return null;
    const badges: Record<string, { color: string; emoji: string }> = {
      silver: { color: '#C0C0C0', emoji: '🥈' },
      gold: { color: '#FFD700', emoji: '🥇' },
      vip: { color: '#a855f7', emoji: '💎' },
    };
    return badges[premium] || null;
  };

  const getMedalOrRank = (i: number) => {
    if (i === 0) return '🥇';
    if (i === 1) return '🥈';
    if (i === 2) return '🥉';
    return `#${i + 1}`;
  };

  return (
    <div className="min-h-screen bg-[#060B14] pb-24 pt-16">
      <div className="px-4 pt-6">
        <h1 className="text-2xl font-bold text-white mb-1">🏆 Leaderboard</h1>
        <p className="text-gray-400 text-sm mb-4">Top miners worldwide</p>

        {/* Tabs */}
        <div className="flex gap-2 mb-4">
          {(['earnings', 'speed'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-all ${
                activeTab === tab
                  ? 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-400'
                  : 'bg-white/5 border border-white/10 text-gray-400'
              }`}
            >
              {tab === 'earnings' ? '💰 Top Earners' : '⚡ Top Speed'}
            </button>
          ))}
        </div>

        {/* Top 3 Podium */}
        {leaders.length >= 3 && (
          <div className="flex items-end justify-center gap-2 mb-6 h-36">
            {/* 2nd Place */}
            <div className="flex flex-col items-center flex-1">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gray-400 to-gray-600 flex items-center justify-center text-xl font-bold mb-1">
                {(leaders[1].name || 'U')[0]}
              </div>
              <div className="text-gray-300 text-xs font-medium truncate w-full text-center">
                {leaders[1].name}
              </div>
              <div className="text-gray-400 text-xs">
                {activeTab === 'earnings' ? `${(leaders[1].total_earned || 0).toFixed(2)} 🪙` : `${leaders[1].mining_speed}x`}
              </div>
              <div className="w-full bg-gradient-to-b from-gray-400 to-gray-600 rounded-t-lg mt-2 h-16 flex items-center justify-center text-2xl">
                🥈
              </div>
            </div>

            {/* 1st Place */}
            <div className="flex flex-col items-center flex-1">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center text-2xl font-bold mb-1">
                {(leaders[0].name || 'U')[0]}
              </div>
              <div className="text-white text-xs font-bold truncate w-full text-center">
                {leaders[0].name}
              </div>
              <div className="text-yellow-400 text-xs font-bold">
                {activeTab === 'earnings' ? `${(leaders[0].total_earned || 0).toFixed(2)} 🪙` : `${leaders[0].mining_speed}x`}
              </div>
              <div className="w-full bg-gradient-to-b from-yellow-400 to-orange-500 rounded-t-lg mt-2 h-24 flex items-center justify-center text-2xl">
                🥇
              </div>
            </div>

            {/* 3rd Place */}
            <div className="flex flex-col items-center flex-1">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-700 to-amber-800 flex items-center justify-center text-xl font-bold mb-1">
                {(leaders[2].name || 'U')[0]}
              </div>
              <div className="text-gray-300 text-xs font-medium truncate w-full text-center">
                {leaders[2].name}
              </div>
              <div className="text-orange-400 text-xs">
                {activeTab === 'earnings' ? `${(leaders[2].total_earned || 0).toFixed(2)} 🪙` : `${leaders[2].mining_speed}x`}
              </div>
              <div className="w-full bg-gradient-to-b from-orange-700 to-amber-800 rounded-t-lg mt-2 h-12 flex items-center justify-center text-2xl">
                🥉
              </div>
            </div>
          </div>
        )}

        {/* Full Leaderboard */}
        {loading ? (
          <div className="flex justify-center py-10">
            <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <div className="space-y-2">
            {leaders.map((entry, i) => {
              const isMe = entry.telegram_id === user?.telegram_id;
              const badge = getPremiumBadge(entry.premium);

              return (
                <GlassCard
                  key={i}
                  className={`p-3 ${isMe ? '' : ''}`}
                  glow={isMe ? 'cyan' : 'none'}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 text-center text-sm">
                      {getMedalOrRank(i)}
                    </div>
                    <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center font-bold text-sm flex-shrink-0">
                      {(entry.name || 'U')[0].toUpperCase()}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className={`font-semibold text-sm truncate ${isMe ? 'text-cyan-400' : 'text-white'}`}>
                          {entry.name} {isMe && '(You)'}
                        </span>
                        {badge && <span className="text-xs">{badge.emoji}</span>}
                      </div>
                      <div className="text-gray-500 text-xs truncate">@{entry.username || 'user'}</div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      {activeTab === 'earnings' ? (
                        <div className="text-yellow-400 font-bold text-sm">
                          🪙 {(entry.total_earned || 0).toFixed(2)}
                        </div>
                      ) : (
                        <div className="text-cyan-400 font-bold text-sm">
                          ⚡ {entry.mining_speed}x
                        </div>
                      )}
                    </div>
                  </div>
                </GlassCard>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
