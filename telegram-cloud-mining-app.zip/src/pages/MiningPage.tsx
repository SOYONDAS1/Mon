import { useState, useEffect, useRef } from 'react';
import { useUser } from '../contexts/UserContext';
import { useMining } from '../contexts/MiningContext';
import { GlassCard } from '../components/ui/GlassCard';
import { NeonButton } from '../components/ui/NeonButton';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

declare const show_11024792: ((type?: string | object) => Promise<void>) | undefined;

// Initialize In-App interstitial ad
setTimeout(() => {
  if (typeof show_11024792 !== 'undefined') {
    try {
      (show_11024792 as (opts: object) => void)({
        type: 'inApp',
        inAppSettings: {
          frequency: 2,
          capping: 0.1,
          interval: 30,
          timeout: 5,
          everyPage: false,
        },
      });
    } catch {}
  }
}, 1000);

const formatTime = (seconds: number) => {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
};

interface Particle {
  id: number;
  x: number;
  y: number;
  value: string;
}

export const MiningPage = () => {
  const { user, refreshUser } = useUser();
  const {
    isMining,
    miningRate,
    sessionEarned,
    elapsedSeconds,
    startMining,
    stopMining,
    currentSpeed,
    boostActive,
    boostTimeLeft,
  } = useMining();

  const [particles, setParticles] = useState<Particle[]>([]);
  const [adLoading, setAdLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const particleIdRef = useRef(0);
  const progressRef = useRef(0);

  // Mining progress animation
  useEffect(() => {
    if (!isMining) {
      setProgress(0);
      progressRef.current = 0;
      return;
    }

    const interval = setInterval(() => {
      progressRef.current = (progressRef.current + currentSpeed * 0.5) % 100;
      setProgress(progressRef.current);

      // Spawn particles
      if (Math.random() < 0.25) {
        const id = particleIdRef.current++;
        const x = 20 + Math.random() * (window.innerWidth - 80);
        const y = 150 + Math.random() * 200;
        const values = ['🪙', '+' + (miningRate * 5).toFixed(5), '✨'];
        const value = values[Math.floor(Math.random() * values.length)];
        setParticles(prev => [...prev.slice(-10), { id, x, y, value }]);
        setTimeout(() => setParticles(prev => prev.filter(p => p.id !== id)), 1200);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [isMining, currentSpeed, miningRate]);

  const speedColor =
    currentSpeed >= 10 ? '#a855f7' :
    currentSpeed >= 5 ? '#FFD700' :
    currentSpeed >= 3 ? '#C0C0C0' :
    currentSpeed >= 2 ? '#22c55e' : '#00d4ff';

  const handleAdBoost = async () => {
    if (adLoading) return;
    setAdLoading(true);
    try {
      if (typeof show_11024792 !== 'undefined') {
        await show_11024792();
      } else {
        await new Promise(r => setTimeout(r, 2000));
      }
      const boostExpiry = new Date(Date.now() + 30 * 60 * 1000).toISOString();
      if (user?.id && user.id !== 'local') {
        await supabase.from('users').update({
          boost_expiry: boostExpiry,
          mining_speed: Math.max(user.mining_speed, 2),
        }).eq('id', user.id);
        await refreshUser();
      }
      toast.success('🚀 2x Mining Boost for 30 minutes!', { duration: 4000 });
    } catch {
      toast.error('Ad unavailable. Try again later.');
    } finally {
      setAdLoading(false);
    }
  };

  const handleAdReward = async () => {
    if (adLoading) return;
    setAdLoading(true);
    try {
      if (typeof show_11024792 !== 'undefined') {
        await (show_11024792 as (t: string) => Promise<void>)('pop');
      } else {
        await new Promise(r => setTimeout(r, 1500));
      }
      toast.success('🎁 +25 coins earned from ad!');
    } catch {
      toast.error('Ad not available');
    } finally {
      setAdLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#060B14] pb-24 pt-16 overflow-hidden">
      {/* Floating Particles */}
      <style>{`
        @keyframes particleFloat {
          0% { transform: translateY(0) scale(1); opacity: 1; }
          100% { transform: translateY(-100px) scale(0.5); opacity: 0; }
        }
        @keyframes orbPulse {
          0%, 100% { box-shadow: 0 0 30px var(--orb-color-a), 0 0 60px var(--orb-color-b); }
          50% { box-shadow: 0 0 60px var(--orb-color-a), 0 0 120px var(--orb-color-b), 0 0 180px var(--orb-color-c); }
        }
        @keyframes rotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        @keyframes rotateReverse {
          from { transform: rotate(360deg); }
          to { transform: rotate(0deg); }
        }
      `}</style>

      {particles.map(p => (
        <div
          key={p.id}
          className="fixed pointer-events-none z-50 text-xs font-bold text-yellow-400"
          style={{
            left: p.x,
            top: p.y,
            animation: 'particleFloat 1.2s ease-out forwards',
          }}
        >
          {p.value}
        </div>
      ))}

      <div className="px-4 pt-6 space-y-4">

        {/* Mining Orb Section */}
        <div className="flex flex-col items-center py-4">
          {/* Main Orb */}
          <div
            className="relative cursor-pointer select-none"
            style={{ width: 200, height: 200 }}
            onClick={isMining ? stopMining : startMining}
          >
            {/* Outer rings - only when mining */}
            {isMining && (
              <>
                <div
                  className="absolute inset-0 rounded-full opacity-20"
                  style={{
                    border: `1px solid ${speedColor}`,
                    animation: 'rotate 8s linear infinite',
                    borderStyle: 'dashed',
                  }}
                />
                <div
                  className="absolute inset-6 rounded-full opacity-15"
                  style={{
                    border: `1px solid ${speedColor}`,
                    animation: 'rotateReverse 5s linear infinite',
                  }}
                />
                {/* Ping rings */}
                <div
                  className="absolute inset-0 rounded-full"
                  style={{
                    border: `1px solid ${speedColor}`,
                    animation: 'ping 2s ease-in-out infinite',
                    opacity: 0,
                  }}
                />
              </>
            )}

            {/* Main circle */}
            <div
              className="absolute inset-4 rounded-full flex flex-col items-center justify-center"
              style={{
                background: `radial-gradient(circle at 35% 30%, ${speedColor}25, transparent 50%),
                             radial-gradient(circle at 65% 70%, #1a0a2e30, transparent 50%),
                             linear-gradient(135deg, #0d1628, #060B14)`,
                border: `2px solid ${speedColor}50`,
                '--orb-color-a': `${speedColor}60`,
                '--orb-color-b': `${speedColor}30`,
                '--orb-color-c': `${speedColor}10`,
                boxShadow: isMining
                  ? `0 0 40px ${speedColor}50, 0 0 80px ${speedColor}25, inset 0 0 40px ${speedColor}10`
                  : `0 0 10px rgba(255,255,255,0.03)`,
                animation: isMining ? 'orbPulse 2s ease-in-out infinite' : 'none',
                transition: 'all 0.5s ease',
              } as React.CSSProperties}
            >
              <div
                className="text-5xl mb-1"
                style={{
                  filter: isMining ? `drop-shadow(0 0 15px ${speedColor}) brightness(1.2)` : 'none',
                  transition: 'filter 0.5s ease',
                  animation: isMining ? 'rotate 4s ease-in-out infinite alternate' : 'none',
                  transform: isMining ? 'scale(1.1)' : 'scale(1)',
                }}
              >
                {isMining ? '⛏️' : '▶️'}
              </div>
              <div
                className="text-xs font-bold tracking-widest uppercase"
                style={{ color: speedColor }}
              >
                {isMining ? 'MINING' : 'START'}
              </div>
              {isMining && (
                <div className="text-gray-400 text-xs mt-0.5">
                  +{(miningRate * 3600).toFixed(4)}/hr
                </div>
              )}
            </div>
          </div>

          {/* Speed Badge */}
          <div
            className="mt-3 px-5 py-1.5 rounded-full font-bold text-sm border"
            style={{
              color: speedColor,
              borderColor: speedColor + '50',
              background: speedColor + '15',
              boxShadow: `0 0 15px ${speedColor}30`,
            }}
          >
            ⚡ {currentSpeed}x Mining Speed
          </div>
        </div>

        {/* Session Stats - when mining */}
        {isMining && (
          <GlassCard className="p-4" glow="cyan">
            <div className="flex justify-between text-xs text-gray-400 mb-2">
              <span>⛏️ Mining in Progress</span>
              <span className="text-green-400 font-medium">{formatTime(elapsedSeconds)}</span>
            </div>

            <div className="h-2 bg-gray-800/80 rounded-full overflow-hidden mb-3 relative">
              <div
                className="h-full rounded-full transition-none"
                style={{
                  width: `${progress}%`,
                  background: `linear-gradient(90deg, #00d4ff, ${speedColor})`,
                  boxShadow: `0 0 12px ${speedColor}`,
                }}
              />
              {/* Animated shimmer */}
              <div
                className="absolute inset-0 opacity-30"
                style={{
                  background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)',
                  backgroundSize: '200% 100%',
                  animation: 'shimmer 1.5s ease-in-out infinite',
                }}
              />
            </div>

            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-white/5 rounded-xl p-2">
                <div className="text-yellow-400 font-bold text-sm">{sessionEarned.toFixed(6)}</div>
                <div className="text-gray-500 text-xs">🪙 Session</div>
              </div>
              <div className="bg-white/5 rounded-xl p-2">
                <div className="text-cyan-400 font-bold text-sm">{(miningRate * 3600).toFixed(4)}</div>
                <div className="text-gray-500 text-xs">Per Hour</div>
              </div>
              <div className="bg-white/5 rounded-xl p-2">
                <div className="text-green-400 font-bold text-sm">{(miningRate * 86400).toFixed(2)}</div>
                <div className="text-gray-500 text-xs">Per Day</div>
              </div>
            </div>
          </GlassCard>
        )}

        {/* Boost Status */}
        {boostActive && (
          <GlassCard className="p-3" glow="green">
            <div className="flex items-center gap-2">
              <span className="text-2xl">🚀</span>
              <div className="flex-1">
                <div className="text-green-400 font-semibold text-sm">Ad Boost Active!</div>
                <div className="h-1 bg-gray-800 rounded-full mt-1 overflow-hidden">
                  <div
                    className="h-full bg-green-400 rounded-full transition-all"
                    style={{ width: `${Math.min(100, (boostTimeLeft / 1800) * 100)}%` }}
                  />
                </div>
              </div>
              <div>
                <div className="text-green-400 font-bold">2x</div>
                <div className="text-gray-500 text-xs">{formatTime(boostTimeLeft)}</div>
              </div>
            </div>
          </GlassCard>
        )}

        {/* Controls */}
        <div className="space-y-3">
          <NeonButton
            variant={isMining ? 'red' : 'cyan'}
            size="lg"
            fullWidth
            onClick={isMining ? stopMining : startMining}
          >
            <span className="text-lg">{isMining ? '⏹️' : '⛏️'}</span>
            {isMining ? ' Stop Mining' : ' Start Mining'}
          </NeonButton>

          <div className="grid grid-cols-2 gap-3">
            <NeonButton
              variant="purple"
              size="md"
              fullWidth
              onClick={handleAdBoost}
              loading={adLoading}
              disabled={boostActive}
            >
              {boostActive ? '🚀 Boost Active' : '📺 Watch Ad → 2x'}
            </NeonButton>
            <NeonButton
              variant="green"
              size="md"
              fullWidth
              onClick={handleAdReward}
              loading={adLoading}
            >
              🎁 Ad Coins
            </NeonButton>
          </div>
        </div>

        {/* Mining Stats */}
        <GlassCard className="p-4">
          <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
            <span>📊</span> Mining Stats
          </h3>
          <div className="space-y-2.5">
            {[
              { label: 'Current Speed', value: `${currentSpeed}x`, color: speedColor },
              { label: 'Per Second', value: `${miningRate.toFixed(8)} 🪙`, color: '#00d4ff' },
              { label: 'Per Hour', value: `${(miningRate * 3600).toFixed(6)} 🪙`, color: '#22c55e' },
              { label: 'Per Day', value: `${(miningRate * 86400).toFixed(4)} 🪙`, color: '#a855f7' },
              { label: 'Per Month', value: `${(miningRate * 2592000).toFixed(2)} 🪙`, color: '#FFD700' },
              { label: 'Total Earned', value: `${(user?.total_earned || 0).toFixed(4)} 🪙`, color: '#f97316' },
            ].map((stat, i) => (
              <div key={i} className="flex items-center justify-between py-1 border-b border-white/5 last:border-0">
                <span className="text-gray-400 text-sm">{stat.label}</span>
                <span className="font-semibold text-sm" style={{ color: stat.color }}>{stat.value}</span>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Speed Levels */}
        <GlassCard className="p-4">
          <h3 className="text-white font-semibold mb-3">🚀 Speed Levels</h3>
          <div className="space-y-2">
            {[
              { label: 'Free Miner', speed: '1x', color: '#9ca3af', active: !boostActive && !user?.premium, desc: 'Default' },
              { label: 'Ad Boost', speed: '2x', color: '#22c55e', active: boostActive, desc: 'Watch Ad' },
              { label: 'Silver Plan', speed: '3x', color: '#C0C0C0', active: user?.premium === 'silver', desc: '$9.99/mo' },
              { label: 'Gold Plan', speed: '5x', color: '#FFD700', active: user?.premium === 'gold', desc: '$19.99/mo' },
              { label: 'VIP Plan', speed: '10x', color: '#a855f7', active: user?.premium === 'vip', desc: '$49.99/mo' },
            ].map((level, i) => (
              <div
                key={i}
                className={`flex items-center justify-between p-2.5 rounded-xl transition-all ${
                  level.active ? 'bg-white/10' : 'opacity-60'
                }`}
                style={{ border: level.active ? `1px solid ${level.color}40` : '1px solid transparent' }}
              >
                <div className="flex items-center gap-2">
                  {level.active && (
                    <div className="w-2 h-2 rounded-full animate-pulse" style={{ background: level.color }} />
                  )}
                  {!level.active && <div className="w-2 h-2 rounded-full bg-gray-700" />}
                  <span className="text-gray-300 text-sm">{level.label}</span>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-gray-500 text-xs">{level.desc}</span>
                  <span className="font-bold text-sm" style={{ color: level.color }}>
                    {level.speed}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
