import { useState, useRef } from 'react';
import { useUser } from '../contexts/UserContext';
import { GlassCard } from '../components/ui/GlassCard';
import { NeonButton } from '../components/ui/NeonButton';
import toast from 'react-hot-toast';

declare const show_11024792: ((type?: string | object) => Promise<void>) | undefined;

const SPIN_REWARDS = [
  { label: '5 🪙', value: 5, color: '#9ca3af', probability: 0.30 },
  { label: '10 🪙', value: 10, color: '#00d4ff', probability: 0.25 },
  { label: '25 🪙', value: 25, color: '#22c55e', probability: 0.18 },
  { label: '50 🪙', value: 50, color: '#a855f7', probability: 0.12 },
  { label: '100 🪙', value: 100, color: '#FFD700', probability: 0.08 },
  { label: '200 🪙', value: 200, color: '#f97316', probability: 0.05 },
  { label: '500 🪙', value: 500, color: '#ef4444', probability: 0.015 },
  { label: '1000 🪙', value: 1000, color: '#ec4899', probability: 0.005 },
];

const getRandomReward = () => {
  const rand = Math.random();
  let cumulative = 0;
  for (const reward of SPIN_REWARDS) {
    cumulative += reward.probability;
    if (rand <= cumulative) return reward;
  }
  return SPIN_REWARDS[0];
};

export const SpinPage = () => {
  const { updateBalance } = useUser();
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [lastReward, setLastReward] = useState<typeof SPIN_REWARDS[0] | null>(null);
  const [spinsLeft, setSpinsLeft] = useState(3);
  const [adLoading, setAdLoading] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const spinRef = useRef(rotation);
  spinRef.current = rotation;

  const handleSpin = async (useAd = false) => {
    if (spinning) return;

    if (useAd) {
      setAdLoading(true);
      try {
        if (typeof show_11024792 !== 'undefined') {
          await (show_11024792 as (type: string) => Promise<void>)('pop');
        } else {
          await new Promise(r => setTimeout(r, 1500));
        }
        setSpinsLeft(prev => prev + 1);
        toast.success('🎰 +1 Free Spin added!');
        setAdLoading(false);
        return;
      } catch {
        toast.error('Ad not available');
        setAdLoading(false);
        return;
      }
    }

    if (spinsLeft <= 0) {
      toast.error('No spins left! Watch an ad for more spins.');
      return;
    }

    setSpinsLeft(prev => prev - 1);
    setSpinning(true);
    setShowResult(false);

    const reward = getRandomReward();
    const rewardIndex = SPIN_REWARDS.indexOf(reward);

    // Calculate rotation to land on reward
    const segmentAngle = 360 / SPIN_REWARDS.length;
    const targetAngle = 360 - (rewardIndex * segmentAngle + segmentAngle / 2);
    const totalRotation = spinRef.current + 1440 + targetAngle - (spinRef.current % 360);

    setRotation(totalRotation);

    setTimeout(async () => {
      setSpinning(false);
      setLastReward(reward);
      setShowResult(true);
      await updateBalance(reward.value, 'spin', `Lucky spin reward: ${reward.label}`);
      toast.success(`🎉 You won ${reward.label}!`, { duration: 4000 });
    }, 4000);
  };

  const segmentAngle = 360 / SPIN_REWARDS.length;

  return (
    <div className="min-h-screen bg-[#060B14] pb-24 pt-16">
      <div className="px-4 pt-6">
        <h1 className="text-2xl font-bold text-white mb-1">🎡 Lucky Spin</h1>
        <p className="text-gray-400 text-sm mb-6">Spin for massive coin rewards!</p>

        {/* Spins Counter */}
        <GlassCard className="p-4 mb-6 text-center" glow="gold">
          <div className="flex items-center justify-center gap-4">
            <div>
              <div className="text-3xl font-bold text-yellow-400">{spinsLeft}</div>
              <div className="text-gray-400 text-xs">Spins Left</div>
            </div>
            <div className="h-10 w-px bg-white/10" />
            <NeonButton
              variant="purple"
              size="sm"
              onClick={() => handleSpin(true)}
              loading={adLoading}
            >
              📺 Watch Ad → +1 Spin
            </NeonButton>
          </div>
        </GlassCard>

        {/* Spin Wheel */}
        <div className="flex flex-col items-center mb-6">
          <div className="relative w-72 h-72">
            {/* Pointer */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 z-10 w-0 h-0 
              border-l-[12px] border-r-[12px] border-t-[24px] 
              border-l-transparent border-r-transparent border-t-yellow-400
              filter drop-shadow-[0_0_8px_rgba(255,215,0,0.8)]"
              style={{ marginTop: '-2px' }}
            />

            {/* Wheel */}
            <div
              className="w-full h-full rounded-full relative overflow-hidden border-4 border-white/20"
              style={{
                transform: `rotate(${rotation}deg)`,
                transition: spinning ? 'transform 4s cubic-bezier(0.17, 0.67, 0.12, 0.99)' : 'none',
                boxShadow: '0 0 30px rgba(0,212,255,0.2), inset 0 0 30px rgba(0,0,0,0.5)',
              }}
            >
              {SPIN_REWARDS.map((reward, i) => {
                const angle = i * segmentAngle;
                return (
                  <div
                    key={i}
                    className="absolute w-full h-full"
                    style={{
                      transform: `rotate(${angle}deg)`,
                      transformOrigin: 'center',
                    }}
                  >
                    <div
                      className="absolute top-0 left-1/2 w-0 h-0"
                      style={{
                        borderLeft: '68px solid transparent',
                        borderRight: '68px solid transparent',
                        borderTop: `136px solid ${reward.color}`,
                        marginLeft: '-68px',
                        opacity: 0.85,
                      }}
                    />
                    <div
                      className="absolute text-xs font-bold text-white"
                      style={{
                        top: '25px',
                        left: '50%',
                        transform: `translateX(-50%) rotate(${segmentAngle / 2}deg)`,
                        textShadow: '0 1px 2px rgba(0,0,0,0.8)',
                        whiteSpace: 'nowrap',
                        fontSize: '9px',
                      }}
                    >
                      {reward.label}
                    </div>
                  </div>
                );
              })}

              {/* Center */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-[#060B14] border-4 border-white/20 flex items-center justify-center text-xl z-10">
                  ⛏️
                </div>
              </div>
            </div>
          </div>

          {/* Spin Button */}
          <NeonButton
            variant="cyan"
            size="lg"
            className="mt-6 px-12"
            onClick={() => handleSpin()}
            disabled={spinning || spinsLeft <= 0}
          >
            {spinning ? '🌀 Spinning...' : spinsLeft > 0 ? '🎯 SPIN!' : '❌ No Spins'}
          </NeonButton>
        </div>

        {/* Result */}
        {showResult && lastReward && (
          <GlassCard className="p-6 text-center mb-4" glow="gold">
            <div className="text-5xl mb-2">🎉</div>
            <h2 className="text-white font-bold text-xl">You Won!</h2>
            <div className="text-4xl font-bold mt-2" style={{ color: lastReward.color }}>
              {lastReward.label}
            </div>
            <p className="text-gray-400 text-sm mt-1">Added to your balance!</p>
          </GlassCard>
        )}

        {/* Rewards Table */}
        <GlassCard className="p-4">
          <h3 className="text-white font-semibold mb-3">🎰 Possible Rewards</h3>
          <div className="space-y-2">
            {SPIN_REWARDS.map((reward, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ background: reward.color }} />
                  <span className="text-gray-300 text-sm">{reward.label}</span>
                </div>
                <span className="text-gray-500 text-xs">{(reward.probability * 100).toFixed(1)}%</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};
