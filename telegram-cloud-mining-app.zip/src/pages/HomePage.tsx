import { useNavigate } from 'react-router-dom';
import { useUser } from '../contexts/UserContext';
import { useMining } from '../contexts/MiningContext';
import { GlassCard } from '../components/ui/GlassCard';
import { NeonButton } from '../components/ui/NeonButton';
import { LiveMiningCard } from '../components/mining/LiveMiningCard';
import { PREMIUM_PLANS } from '../types';

export const HomePage = () => {
  const navigate = useNavigate();
  const { user } = useUser();
  const { currentSpeed } = useMining();

  const getPremiumBadge = () => {
    if (!user?.premium) return null;
    const plan = PREMIUM_PLANS.find(p => p.id === user.premium);
    if (!plan) return null;
    return (
      <span
        className="text-xs px-2 py-0.5 rounded-full font-bold border"
        style={{ color: plan.color, borderColor: plan.color + '60', background: plan.color + '20' }}
      >
        {plan.name.toUpperCase()}
      </span>
    );
  };

  return (
    <div className="min-h-screen bg-[#060B14] pb-24 pt-16 relative">
      <div className="px-4 pt-4 space-y-4">

        {/* Welcome Banner */}
        <GlassCard className="p-4" glow="cyan">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400/20 to-purple-500/20 border border-cyan-500/30 flex items-center justify-center text-2xl overflow-hidden">
                {user?.photo_url ? (
                  <img src={user.photo_url} alt="" className="w-full h-full object-cover" />
                ) : (
                  <span className="font-bold text-cyan-400 text-lg">
                    {(user?.name || 'U')[0].toUpperCase()}
                  </span>
                )}
              </div>
              {user?.premium && (
                <div className="absolute -bottom-1 -right-1 text-sm">
                  {user.premium === 'vip' ? '💎' : user.premium === 'gold' ? '🥇' : '🥈'}
                </div>
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-bold text-white text-lg leading-tight">
                  {user?.name?.split(' ')[0] || 'Miner'}
                </h2>
                {getPremiumBadge()}
              </div>
              <p className="text-gray-500 text-xs">@{user?.username || 'user'}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-cyan-400 text-xs">⚡ {currentSpeed}x Speed</span>
                <span className="text-gray-600">•</span>
                <span className="text-green-400 text-xs">🔥 {user?.daily_streak || 0} day streak</span>
              </div>
            </div>
            <div
              className="w-10 h-10 rounded-xl bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-center cursor-pointer"
              onClick={() => navigate('/wallet')}
            >
              💰
            </div>
          </div>
        </GlassCard>

        {/* Live Mining Card */}
        <LiveMiningCard />

        {/* Quick Action Grid */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { icon: '🎁', label: 'Daily', path: '/tasks', color: '#22c55e' },
            { icon: '🎡', label: 'Spin', path: '/spin', color: '#FFD700' },
            { icon: '👥', label: 'Refer', path: '/referral', color: '#a855f7' },
            { icon: '🏆', label: 'Top', path: '/leaderboard', color: '#00d4ff' },
          ].map(item => (
            <GlassCard
              key={item.path}
              className="p-3 text-center"
              onClick={() => navigate(item.path)}
            >
              <div className="text-2xl mb-1">{item.icon}</div>
              <div className="text-xs font-medium" style={{ color: item.color }}>{item.label}</div>
            </GlassCard>
          ))}
        </div>

        {/* Banner: Go Premium */}
        {!user?.premium && (
          <GlassCard className="overflow-hidden" glow="gold">
            <div className="p-4 relative">
              <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/5 rounded-full -translate-y-8 translate-x-8" />
              <div className="flex items-center gap-3">
                <div className="text-4xl">👑</div>
                <div className="flex-1">
                  <h3 className="font-bold text-white">Go Premium</h3>
                  <p className="text-gray-400 text-xs">Mine up to 10x faster today!</p>
                  <div className="flex gap-1 mt-1">
                    {['3x', '5x', '10x'].map(s => (
                      <span key={s} className="text-xs bg-yellow-500/20 border border-yellow-500/40 text-yellow-400 px-1.5 py-0.5 rounded">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
                <NeonButton variant="gold" size="sm" onClick={() => navigate('/premium')}>
                  Upgrade
                </NeonButton>
              </div>
            </div>
          </GlassCard>
        )}

        {/* Feature Cards */}
        <h2 className="text-white font-bold text-base pt-1">⚡ Quick Access</h2>

        <div className="space-y-2">
          {/* Daily Reward */}
          <GlassCard className="p-4" glow="green" onClick={() => navigate('/tasks')}>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-green-500/15 border border-green-500/30 flex items-center justify-center text-2xl">
                🎁
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-white text-sm">Daily Reward</h3>
                <p className="text-gray-400 text-xs">Claim your daily mining bonus</p>
              </div>
              <div className="text-right">
                <div className="text-green-400 font-bold text-sm">+50 🪙</div>
                <div className="text-gray-500 text-xs">Streak x{user?.daily_streak || 0}</div>
              </div>
            </div>
          </GlassCard>

          {/* Referral */}
          <GlassCard className="p-4" glow="purple" onClick={() => navigate('/referral')}>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-2xl">
                👥
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-white text-sm">Invite Friends</h3>
                <p className="text-gray-400 text-xs">Earn 100 coins per referral</p>
              </div>
              <div className="text-right">
                <div className="text-purple-400 font-bold text-sm">+100 🪙</div>
                <div className="text-gray-500 text-xs">Per Friend</div>
              </div>
            </div>
          </GlassCard>

          {/* Lucky Spin */}
          <GlassCard className="p-4" glow="gold" onClick={() => navigate('/spin')}>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-yellow-500/15 border border-yellow-500/30 flex items-center justify-center text-2xl">
                🎡
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-white text-sm">Lucky Spin</h3>
                <p className="text-gray-400 text-xs">Win up to 1,000 coins!</p>
              </div>
              <div className="text-right">
                <div className="text-yellow-400 font-bold text-sm">Win Big!</div>
                <div className="text-gray-500 text-xs">Free Spin</div>
              </div>
            </div>
          </GlassCard>
        </div>

        {/* Premium Plans Preview */}
        <div>
          <h2 className="text-white font-bold text-base mb-3">🚀 Speed Plans</h2>
          <div className="grid grid-cols-3 gap-2">
            {PREMIUM_PLANS.map((plan) => (
              <GlassCard
                key={plan.id}
                className="p-3 text-center"
                onClick={() => navigate('/premium')}
                style={{ borderColor: user?.premium === plan.id ? plan.color + '60' : undefined }}
              >
                <div className="text-2xl mb-1">
                  {plan.id === 'silver' ? '🥈' : plan.id === 'gold' ? '🥇' : '💎'}
                </div>
                <div className="text-xs font-bold" style={{ color: plan.color }}>{plan.name}</div>
                <div className="text-cyan-400 text-sm font-bold">{plan.speed}x</div>
                <div className="text-gray-500 text-xs">${plan.price}/mo</div>
              </GlassCard>
            ))}
          </div>
        </div>

        {/* Stats Footer */}
        <GlassCard className="p-4">
          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <div className="text-cyan-400 font-bold text-sm">{(user?.total_earned || 0).toFixed(4)}</div>
              <div className="text-gray-500 text-xs">Total Earned</div>
            </div>
            <div>
              <div className="text-yellow-400 font-bold text-sm">{(user?.balance || 0).toFixed(4)}</div>
              <div className="text-gray-500 text-xs">Balance</div>
            </div>
            <div>
              <div className="text-purple-400 font-bold text-sm">{user?.daily_streak || 0}</div>
              <div className="text-gray-500 text-xs">Day Streak</div>
            </div>
          </div>
        </GlassCard>

        {/* Footer */}
        <div className="text-center pb-2">
          <p className="text-gray-700 text-xs">⚡ CryptoMine Pro • Simulation Platform</p>
        </div>
      </div>
    </div>
  );
};
