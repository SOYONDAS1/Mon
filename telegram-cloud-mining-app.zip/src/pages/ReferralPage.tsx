import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useUser } from '../contexts/UserContext';
import { GlassCard } from '../components/ui/GlassCard';
import { NeonButton } from '../components/ui/NeonButton';
import { useTelegram } from '../contexts/TelegramContext';
import toast from 'react-hot-toast';

interface ReferralEntry {
  id: string;
  referred_id: string;
  reward: number;
  created_at: string;
  referred_user?: { name: string; username: string };
}

interface LeaderEntry {
  name: string;
  username: string;
  total_earned: number;
  telegram_id: string;
}

export const ReferralPage = () => {
  const { user } = useUser();
  const { webApp } = useTelegram();
  const [referrals, setReferrals] = useState<ReferralEntry[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderEntry[]>([]);
  const [activeTab, setActiveTab] = useState<'refer' | 'leaderboard'>('refer');

  useEffect(() => {
    if (user?.id && user.id !== 'local') {
      fetchReferrals();
    }
    fetchLeaderboard();
  }, [user]);

  const fetchReferrals = async () => {
    if (!user?.id || user.id === 'local') return;
    const { data } = await supabase
      .from('referrals')
      .select('*')
      .eq('referrer_id', user.id)
      .order('created_at', { ascending: false });
    if (data) setReferrals(data);
  };

  const fetchLeaderboard = async () => {
    const { data } = await supabase
      .from('users')
      .select('name, username, total_earned, telegram_id')
      .order('total_earned', { ascending: false })
      .limit(20);
    if (data) setLeaderboard(data);
  };

  const referralLink = `https://t.me/CryptomineProBot?start=${user?.referral_code}`;

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink).then(() => {
      toast.success('✅ Referral link copied!');
    }).catch(() => {
      toast.error('Failed to copy');
    });
  };

  const shareLink = () => {
    if (webApp) {
      webApp.openTelegramLink(
        `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent('🚀 Join CryptoMine Pro and earn crypto! Use my link to get a bonus!')}`
      );
    } else {
      window.open(
        `https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=${encodeURIComponent('🚀 Join CryptoMine Pro!')}`,
        '_blank'
      );
    }
  };

  const totalReferralEarnings = referrals.reduce((sum, r) => sum + r.reward, 0);

  return (
    <div className="min-h-screen bg-[#060B14] pb-24 pt-16">
      <div className="px-4 pt-6">
        {/* Header */}
        <h1 className="text-2xl font-bold text-white mb-1">Referral Program</h1>
        <p className="text-gray-400 text-sm mb-4">Invite friends and earn together</p>

        {/* Tabs */}
        <div className="flex gap-2 mb-4">
          {(['refer', 'leaderboard'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 rounded-xl text-sm font-semibold transition-all ${
                activeTab === tab
                  ? 'bg-purple-500/20 border border-purple-500/50 text-purple-400'
                  : 'bg-white/5 border border-white/10 text-gray-400'
              }`}
            >
              {tab === 'refer' ? '👥 Refer' : '🏆 Leaders'}
            </button>
          ))}
        </div>

        {activeTab === 'refer' ? (
          <div className="space-y-4">
            {/* Referral Stats */}
            <div className="grid grid-cols-2 gap-3">
              <GlassCard className="p-4 text-center" glow="purple">
                <div className="text-3xl font-bold text-purple-400">{referrals.length}</div>
                <div className="text-gray-400 text-xs mt-1">Total Referrals</div>
              </GlassCard>
              <GlassCard className="p-4 text-center" glow="gold">
                <div className="text-3xl font-bold text-yellow-400">{totalReferralEarnings.toFixed(0)}</div>
                <div className="text-gray-400 text-xs mt-1">🪙 Earned</div>
              </GlassCard>
            </div>

            {/* How it works */}
            <GlassCard className="p-4">
              <h3 className="text-white font-semibold mb-3">🎯 How It Works</h3>
              <div className="space-y-3">
                {[
                  { step: '1', text: 'Share your unique referral link', icon: '🔗' },
                  { step: '2', text: 'Friend joins via your link', icon: '👤' },
                  { step: '3', text: 'You earn 100 coins instantly', icon: '🪙' },
                  { step: '4', text: 'Earn 5% of their mining forever', icon: '💎' },
                ].map(item => (
                  <div key={item.step} className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 font-bold text-sm">
                      {item.step}
                    </div>
                    <span className="text-gray-300 text-sm">{item.icon} {item.text}</span>
                  </div>
                ))}
              </div>
            </GlassCard>

            {/* Referral Link */}
            <GlassCard className="p-4" glow="cyan">
              <h3 className="text-white font-semibold mb-2">🔗 Your Referral Link</h3>
              <div className="flex items-center gap-2 bg-white/5 rounded-xl p-3 mb-3">
                <span className="text-cyan-400 text-xs flex-1 truncate">{referralLink}</span>
              </div>
              <div className="flex gap-2">
                <NeonButton variant="ghost" size="md" fullWidth onClick={copyLink}>
                  📋 Copy
                </NeonButton>
                <NeonButton variant="cyan" size="md" fullWidth onClick={shareLink}>
                  📤 Share
                </NeonButton>
              </div>
            </GlassCard>

            {/* Referral Code */}
            <GlassCard className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-white font-semibold">Your Code</h3>
                  <div className="text-2xl font-bold text-cyan-400 font-mono mt-1">
                    {user?.referral_code}
                  </div>
                </div>
                <NeonButton
                  variant="cyan"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(user?.referral_code || '');
                    toast.success('Code copied!');
                  }}
                >
                  Copy
                </NeonButton>
              </div>
            </GlassCard>

            {/* Recent Referrals */}
            {referrals.length > 0 && (
              <div>
                <h3 className="text-white font-semibold mb-2">Recent Referrals</h3>
                {referrals.slice(0, 5).map(ref => (
                  <GlassCard key={ref.id} className="p-3 mb-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-purple-500/20 flex items-center justify-center">
                          👤
                        </div>
                        <div>
                          <div className="text-white text-sm">Friend Joined</div>
                          <div className="text-gray-500 text-xs">
                            {new Date(ref.created_at).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                      <div className="text-green-400 font-bold">+{ref.reward} 🪙</div>
                    </div>
                  </GlassCard>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-2">
            {leaderboard.length === 0 ? (
              <GlassCard className="p-8 text-center">
                <div className="text-4xl mb-2">🏆</div>
                <p className="text-gray-400">Leaderboard loading...</p>
              </GlassCard>
            ) : (
              leaderboard.map((entry, i) => {
                const isMe = entry.telegram_id === user?.telegram_id;
                const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : null;

                return (
                  <GlassCard
                    key={i}
                    className={`p-3 ${isMe ? 'border-cyan-500/50' : ''}`}
                    glow={isMe ? 'cyan' : 'none'}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 text-center">
                        {medal || <span className="text-gray-500 text-sm">#{i + 1}</span>}
                      </div>
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center font-bold text-sm">
                        {(entry.name || 'U')[0].toUpperCase()}
                      </div>
                      <div className="flex-1">
                        <div className={`font-semibold text-sm ${isMe ? 'text-cyan-400' : 'text-white'}`}>
                          {entry.name} {isMe && '(You)'}
                        </div>
                        <div className="text-gray-500 text-xs">@{entry.username || 'user'}</div>
                      </div>
                      <div className="text-yellow-400 font-bold text-sm">
                        🪙 {(entry.total_earned || 0).toFixed(2)}
                      </div>
                    </div>
                  </GlassCard>
                );
              })
            )}
          </div>
        )}
      </div>
    </div>
  );
};
