import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useUser } from '../contexts/UserContext';
import { User, Withdrawal } from '../types';
import { GlassCard } from '../components/ui/GlassCard';
import { NeonButton } from '../components/ui/NeonButton';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

export const AdminPage = () => {
  const { user, isAdmin } = useUser();
  const navigate = useNavigate();
  const [users, setUsers] = useState<User[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [stats, setStats] = useState({ totalUsers: 0, totalEarned: 0, pendingWithdrawals: 0 });
  const [activeTab, setActiveTab] = useState<'stats' | 'users' | 'withdrawals'>('stats');
  const [loading, setLoading] = useState(true);
  const [bonusUserId, setBonusUserId] = useState('');
  const [bonusAmount, setBonusAmount] = useState('');

  useEffect(() => {
    if (!isAdmin) {
      navigate('/');
      return;
    }
    fetchData();
  }, [isAdmin]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: usersData, count } = await supabase
        .from('users')
        .select('*', { count: 'exact' })
        .order('created_at', { ascending: false })
        .limit(100);

      const { data: withdrawalsData } = await supabase
        .from('withdrawals')
        .select('*')
        .order('created_at', { ascending: false });

      if (usersData) {
        setUsers(usersData);
        const totalEarned = usersData.reduce((sum: number, u: User) => sum + (u.total_earned || 0), 0);
        const pendingWd = withdrawalsData?.filter((w: Withdrawal) => w.status === 'pending').length || 0;
        setStats({ totalUsers: count || usersData.length, totalEarned, pendingWithdrawals: pendingWd });
      }

      if (withdrawalsData) setWithdrawals(withdrawalsData);
    } catch (err) {
      console.error(err);
    }
    setLoading(false);
  };

  const toggleBan = async (userId: string, isBanned: boolean) => {
    await supabase.from('users').update({ is_banned: !isBanned }).eq('id', userId);
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, is_banned: !isBanned } : u));
    toast.success(isBanned ? 'User unbanned' : 'User banned');
  };

  const addBonus = async () => {
    if (!bonusUserId || !bonusAmount) {
      toast.error('Fill all fields');
      return;
    }
    const amount = parseFloat(bonusAmount);
    const targetUser = users.find(u => u.telegram_id === bonusUserId || u.id === bonusUserId);
    if (!targetUser) {
      toast.error('User not found');
      return;
    }

    await supabase.from('users').update({ balance: (targetUser.balance || 0) + amount }).eq('id', targetUser.id);
    await supabase.from('transactions').insert([{
      user_id: targetUser.id,
      type: 'bonus',
      amount,
      description: 'Admin bonus',
    }]);

    toast.success(`✅ Added ${amount} coins to ${targetUser.name}`);
    setBonusUserId('');
    setBonusAmount('');
    fetchData();
  };

  const handleWithdrawal = async (wdId: string, status: 'completed' | 'rejected') => {
    await supabase.from('withdrawals').update({ status }).eq('id', wdId);
    setWithdrawals(prev => prev.map(w => w.id === wdId ? { ...w, status } : w));
    toast.success(`Withdrawal ${status}`);
  };

  if (!isAdmin) return null;

  return (
    <div className="min-h-screen bg-[#060B14] pb-24 pt-16">
      <div className="px-4 pt-6">
        {/* Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="text-3xl">🛡️</div>
          <div>
            <h1 className="text-2xl font-bold text-white">Admin Panel</h1>
            <p className="text-gray-400 text-xs">Hello, {user?.name}</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-4 overflow-x-auto">
          {(['stats', 'users', 'withdrawals'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all whitespace-nowrap min-w-fit px-3 ${
                activeTab === tab
                  ? 'bg-red-500/20 border border-red-500/50 text-red-400'
                  : 'bg-white/5 border border-white/10 text-gray-400'
              }`}
            >
              {tab === 'stats' ? '📊 Stats' : tab === 'users' ? '👥 Users' : '💸 Withdrawals'}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="flex justify-center py-10">
            <div className="w-8 h-8 border-2 border-red-400 border-t-transparent rounded-full animate-spin" />
          </div>
        ) : (
          <>
            {activeTab === 'stats' && (
              <div className="space-y-4">
                {/* Stats Cards */}
                <div className="grid grid-cols-3 gap-3">
                  <GlassCard className="p-3 text-center">
                    <div className="text-2xl font-bold text-cyan-400">{stats.totalUsers}</div>
                    <div className="text-gray-500 text-xs">Total Users</div>
                  </GlassCard>
                  <GlassCard className="p-3 text-center">
                    <div className="text-2xl font-bold text-yellow-400">{stats.totalEarned.toFixed(0)}</div>
                    <div className="text-gray-500 text-xs">Total Earned</div>
                  </GlassCard>
                  <GlassCard className="p-3 text-center">
                    <div className="text-2xl font-bold text-red-400">{stats.pendingWithdrawals}</div>
                    <div className="text-gray-500 text-xs">Pending WD</div>
                  </GlassCard>
                </div>

                {/* Add Bonus */}
                <GlassCard className="p-4">
                  <h3 className="text-white font-semibold mb-3">💰 Add Bonus Coins</h3>
                  <div className="space-y-2">
                    <input
                      type="text"
                      value={bonusUserId}
                      onChange={e => setBonusUserId(e.target.value)}
                      placeholder="User Telegram ID or User ID"
                      className="w-full bg-white/5 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-gray-600 text-sm focus:border-red-500/50 focus:outline-none"
                    />
                    <input
                      type="number"
                      value={bonusAmount}
                      onChange={e => setBonusAmount(e.target.value)}
                      placeholder="Amount"
                      className="w-full bg-white/5 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-gray-600 text-sm focus:border-red-500/50 focus:outline-none"
                    />
                    <NeonButton variant="green" fullWidth onClick={addBonus}>
                      Add Bonus
                    </NeonButton>
                  </div>
                </GlassCard>

                {/* Platform stats */}
                <GlassCard className="p-4">
                  <h3 className="text-white font-semibold mb-3">📈 Platform Stats</h3>
                  <div className="space-y-2">
                    {[
                      { label: 'Premium Users', value: users.filter(u => u.premium).length },
                      { label: 'Active Miners', value: users.filter(u => u.mining_speed > 1).length },
                      { label: 'Banned Users', value: users.filter(u => u.is_banned).length },
                      { label: 'Avg Balance', value: (users.reduce((s, u) => s + u.balance, 0) / Math.max(users.length, 1)).toFixed(2) + ' 🪙' },
                    ].map((stat, i) => (
                      <div key={i} className="flex justify-between items-center py-1 border-b border-white/5 last:border-0">
                        <span className="text-gray-400 text-sm">{stat.label}</span>
                        <span className="text-white font-semibold text-sm">{stat.value}</span>
                      </div>
                    ))}
                  </div>
                </GlassCard>
              </div>
            )}

            {activeTab === 'users' && (
              <div className="space-y-2">
                {users.map(u => (
                  <GlassCard key={u.id} className={`p-3 ${u.is_banned ? 'opacity-50' : ''}`}>
                    <div className="flex items-start gap-2">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center font-bold text-sm flex-shrink-0">
                        {(u.name || 'U')[0].toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1 flex-wrap">
                          <span className="text-white font-semibold text-sm truncate">{u.name}</span>
                          {u.premium && <span className="text-xs text-yellow-400">👑{u.premium}</span>}
                          {u.is_admin && <span className="text-xs text-red-400">ADMIN</span>}
                          {u.is_banned && <span className="text-xs text-red-400">BANNED</span>}
                        </div>
                        <div className="text-gray-500 text-xs">
                          @{u.username} • ID: {u.telegram_id}
                        </div>
                        <div className="flex gap-2 text-xs mt-0.5">
                          <span className="text-yellow-400">💰{u.balance.toFixed(2)}</span>
                          <span className="text-cyan-400">⚡{u.mining_speed}x</span>
                        </div>
                      </div>
                      <NeonButton
                        variant={u.is_banned ? 'green' : 'red'}
                        size="sm"
                        onClick={() => toggleBan(u.id, u.is_banned)}
                      >
                        {u.is_banned ? 'Unban' : 'Ban'}
                      </NeonButton>
                    </div>
                  </GlassCard>
                ))}
              </div>
            )}

            {activeTab === 'withdrawals' && (
              <div className="space-y-2">
                {withdrawals.map(wd => (
                  <GlassCard key={wd.id} className="p-3">
                    <div className="flex items-start gap-2">
                      <div className="flex-1">
                        <div className="text-white text-sm font-medium">{wd.amount.toFixed(2)} 🪙</div>
                        <div className="text-gray-500 text-xs truncate">{wd.wallet}</div>
                        <div className="text-gray-600 text-xs">{new Date(wd.created_at).toLocaleDateString()}</div>
                      </div>
                      <div className="flex flex-col gap-1">
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          wd.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                          wd.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                          'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {wd.status}
                        </span>
                        {wd.status === 'pending' && (
                          <div className="flex gap-1">
                            <NeonButton variant="green" size="sm" onClick={() => handleWithdrawal(wd.id, 'completed')}>
                              ✓
                            </NeonButton>
                            <NeonButton variant="red" size="sm" onClick={() => handleWithdrawal(wd.id, 'rejected')}>
                              ✗
                            </NeonButton>
                          </div>
                        )}
                      </div>
                    </div>
                  </GlassCard>
                ))}
                {withdrawals.length === 0 && (
                  <GlassCard className="p-8 text-center">
                    <p className="text-gray-400">No withdrawals yet</p>
                  </GlassCard>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
