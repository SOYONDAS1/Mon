import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://eikazfkdszoxamtupbuz.supabase.co';
const supabaseAnonKey = 'sb_publishable_I9TKVUvxBfcEdivZgcVj0A_WrJq6gQC';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export default supabase;
