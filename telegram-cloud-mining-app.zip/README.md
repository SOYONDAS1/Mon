# 🚀 CryptoMine Pro - Telegram Mini App

A full production-ready Telegram Mini App cloud mining simulation platform with modern crypto UI and complete monetization system.

## ✨ Features

- 🤖 **Telegram Integration** - Auto login via Telegram SDK
- ⛏️ **Cloud Mining Simulation** - Real-time mining with animations
- 💰 **Wallet System** - Balance tracking & withdrawal requests
- 👑 **Premium Plans** - Silver/Gold/VIP speed multipliers
- 📺 **Monetag Ads** - Rewarded ads for boosts & coins
- 🎡 **Lucky Spin** - Spin wheel with coin prizes
- 👥 **Referral System** - Invite friends & earn rewards
- ✅ **Tasks System** - Complete tasks for bonus coins
- 🏆 **Leaderboard** - Top miners ranking
- 🛡️ **Admin Panel** - User management & stats
- 🗓️ **Daily Rewards** - Streak-based daily bonuses

## 🛠️ Tech Stack

- **Frontend**: React 19 + Vite + TypeScript
- **Styling**: Tailwind CSS 4
- **Backend**: Supabase (PostgreSQL)
- **Auth**: Telegram Web Apps SDK
- **Ads**: Monetag (Zone ID: 11024792)
- **Routing**: React Router v6
- **Notifications**: React Hot Toast
- **Icons**: Lucide React

## 📱 Mining Speed Levels

| Plan | Speed | Price |
|------|-------|-------|
| Free | 1x | Free |
| Ad Boost | 2x | Watch Ad |
| Silver | 3x | $9.99/mo |
| Gold | 5x | $19.99/mo |
| VIP | 10x | $49.99/mo |

## 🚀 Deployment

### 1. Clone & Install
```bash
git clone <your-repo>
cd cryptomine-pro
npm install
```

### 2. Set up Supabase
1. Create a new Supabase project at [supabase.com](https://supabase.com)
2. Run the `supabase_schema.sql` in the SQL editor
3. Copy your Project URL and anon key

### 3. Environment Variables
Update `src/lib/supabase.ts` with your credentials:
```typescript
const supabaseUrl = 'YOUR_SUPABASE_URL';
const supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';
```

Or create a `.env` file and update `vite.config.ts` to use env vars.

### 4. Deploy to Vercel
```bash
npm run build
npx vercel --prod
```

Or connect GitHub repo to Vercel for auto-deploy.

### 5. Set Up Telegram Bot
1. Create a bot with [@BotFather](https://t.me/BotFather)
2. Use `/newapp` to create a Mini App
3. Set your Vercel deployment URL as the Mini App URL

### 6. Set Admin
In Supabase SQL editor, run:
```sql
UPDATE users SET is_admin = TRUE WHERE telegram_id = 'YOUR_TELEGRAM_ID';
```

## 📊 Database Schema

### Tables
- `users` - User profiles and balances
- `mining_sessions` - Mining session tracking
- `transactions` - All coin movements
- `tasks` - Available tasks
- `user_tasks` - Completed tasks
- `withdrawals` - Withdrawal requests
- `referrals` - Referral tracking

## 💰 Monetization

1. **Monetag Ads**
   - Rewarded Interstitial (mining boost)
   - Rewarded Popup (coin reward)
   - In-App Interstitial

2. **Premium Plans**
   - Crypto payment integration
   - Silver/Gold/VIP tiers

3. **Referral System**
   - 100 coins per referral
   - 5% lifetime commission

## 🔒 Security

- Supabase Row Level Security (RLS)
- Balances stored server-side
- Input validation on all forms
- Admin-only routes protected

## 🎨 UI Features

- Dark mode with neon glow effects
- Glassmorphism cards
- Mining animations
- Coin particle effects
- Progress bars
- Responsive mobile-first design

## 📝 License

MIT License - Free to use and modify

---
Made with ❤️ for the Telegram ecosystem
